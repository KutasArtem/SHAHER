import { GoogleGenAI, Type } from "@google/genai";
import { Mission, Vector2 } from "../types";
import { GAME_WIDTH, GAME_HEIGHT } from "../constants";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export const generateMissionScenario = async (difficulty: string): Promise<Mission> => {
  const prompt = `
    Generate a tactical drone simulation scenario. 
    Map dimensions: ${GAME_WIDTH}x${GAME_HEIGHT}.
    Difficulty: ${difficulty}.
    
    I need a mission name (in Russian), a briefing (in Russian), coordinates for 3-6 air defense systems (PVO), and 1 main target coordinate.
    Defense coordinates should be strategically placed to block the path to the target.
    Avoid placing objects too close to the edges (keep buffer of 50px).
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            missionName: { type: Type.STRING },
            briefing: { type: Type.STRING },
            defenses: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  x: { type: Type.NUMBER },
                  y: { type: Type.NUMBER }
                }
              }
            },
            target: {
              type: Type.OBJECT,
              properties: {
                x: { type: Type.NUMBER },
                y: { type: Type.NUMBER }
              }
            }
          }
        }
      }
    });

    let jsonString = response.text || '{}';
    // Sanitize markdown code blocks if present
    jsonString = jsonString.replace(/```json/g, '').replace(/```/g, '').trim();

    const data = JSON.parse(jsonString);
    
    return {
      name: String(data.missionName || "Unknown Operation"),
      briefing: String(data.briefing || "No intel available."),
      defenses: Array.isArray(data.defenses) ? data.defenses.map((d: any) => ({ x: Number(d.x), y: Number(d.y) })) : [],
      target: data.target ? { x: Number(data.target.x), y: Number(data.target.y) } : { x: GAME_WIDTH - 100, y: GAME_HEIGHT / 2 },
      difficulty: difficulty as any
    };

  } catch (error) {
    console.error("Gemini generation failed:", String(error));
    // Fallback mission
    return {
      name: "Операция: Резервный Канал",
      briefing: "Связь со штабом (Gemini) потеряна. Используйте стандартную тактическую карту.",
      defenses: [
        { x: 600, y: 300 },
        { x: 600, y: 500 },
        { x: 400, y: 400 }
      ],
      target: { x: 1000, y: 400 },
      difficulty: 'Medium'
    };
  }
};

export const analyzeTacticalOutcome = async (success: boolean, dronesUsed: number, timeTaken: number) => {
  const prompt = `
    Tactical Report.
    Status: ${success ? 'Mission Accomplished' : 'Mission Failed'}.
    Drones Used: ${dronesUsed}.
    Time: ${timeTaken} seconds.
    
    Write a short, military-style After Action Report (in Russian). Be brief and strict.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text || "No tactical analysis available.";
  } catch (e) {
    return "Data corruption in AAR uplink.";
  }
};