

export interface Vector2 {
  x: number;
  y: number;
}

export type DroneType = 'ATTACK' | 'SCOUT' | 'TURBO' | 'STEALTH';

export interface Drone {
  id: string;
  type: DroneType;
  pos: Vector2;
  velocity: Vector2;
  angle: number; // in radians
  target: Vector2 | null;
  active: boolean;
  trail: Vector2[];
  returning?: boolean; // If true, flying back to spawn
  jammed?: boolean; // New: Affected by EW
}

export interface Defense {
  id: string;
  pos: Vector2;
  range: number;
  cooldown: number;
  lastFired: number;
  type: 'SAM' | 'AA_GUN' | 'FLAK';
  angle: number; // Turret facing
  revealed?: boolean; // Fog of War status
  health: number;
  maxHealth: number;
  powered?: boolean; // New: Needs power plant connection
  targetId?: string | null; // Visual locking logic
}

export type InfrastructureType = 'POWER_PLANT' | 'WAREHOUSE' | 'RADAR' | 'COMMAND_CENTER' | 'JAMMER' | 'FUEL_DEPOT';

export interface Infrastructure {
    id: string;
    type: InfrastructureType;
    pos: Vector2;
    health: number;
    maxHealth: number;
    revealed: boolean;
    destroyed: boolean;
    destroyedTime?: number; // Timestamp when it was destroyed
}

export interface Projectile {
  id: string;
  type: 'BULLET' | 'MISSILE' | 'FLAK_SHELL';
  pos: Vector2;
  velocity: Vector2;
  speed: number;
  targetId: string | null; // Flak might just shoot at a pos
  targetPos?: Vector2; // For Flak detonation point
  active: boolean;
  birthTime: number;
  trail: Vector2[]; // For missiles
}

export interface Particle {
  id: string;
  pos: Vector2;
  velocity: Vector2;
  life: number; // 0 to 1
  decay: number;
  color: string;
  size: number;
  type: 'SPARK' | 'SMOKE' | 'DEBRIS';
}

export interface Shockwave {
  id: string;
  pos: Vector2;
  radius: number;
  maxRadius: number;
  alpha: number;
}

export interface Explosion {
  id: string;
  pos: Vector2;
  radius: number;
  maxRadius: number;
  alpha: number;
  color: string;
  damage: boolean; // If true, this explosion kills drones
}

export interface FloatingText {
  id: string;
  pos: Vector2;
  text: string;
  color: string;
  life: number; // 1.0 to 0
  velocity: Vector2;
}

export interface Mission {
  name: string;
  briefing: string;
  defenses: Vector2[];
  target: Vector2;
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

export interface LogEntry {
  id: string;
  time: string;
  message: string;
  type: 'info' | 'success' | 'danger' | 'warning';
}

export interface Medal {
    id: string;
    name: string;
    description: string;
    icon: string; // Lucide icon name mapping
    unlocked: boolean;
}

export enum ViewState {
  MENU = 'MENU',
  GAME = 'GAME',
  GAME_OVER = 'GAME_OVER' // For Attack/Survival results
}

export enum GameMode {
  SANDBOX = 'SANDBOX',
  ATTACK = 'ATTACK',
  SURVIVAL = 'SURVIVAL',
  REALISTIC = 'REALISTIC',
  BASE_DEFENSE = 'BASE_DEFENSE', // New: Player defends against AI drones
  NIGHT_OPS = 'NIGHT_OPS' // New: Low visibility
}

export enum ToolMode {
  SET_TARGET = 'SET_TARGET',
  PLACE_DEFENSE = 'PLACE_DEFENSE',
  PLACE_SPAWN = 'PLACE_SPAWN',
  PLACE_INFRASTRUCTURE = 'PLACE_INFRASTRUCTURE',
  DELETE = 'DELETE'
}

export type KeyAction = 'LAUNCH' | 'TYPE_ATTACK' | 'TYPE_SCOUT' | 'TYPE_TURBO' | 'PAUSE' | 'TOOL_TARGET' | 'TOOL_DELETE' | 'TOGGLE_FOG';
export type KeyBindings = Record<KeyAction, string>;

export type ShopCategory = 'FINANCE' | 'SUPPORT' | 'TECH';

export interface ShopItem {
    id: string;
    category: ShopCategory;
    name: string;
    description: string;
    cost: number; // If finance, this is real money (simulated), else credits
    currency: 'USD' | 'CREDITS';
    icon: any; // Lucide icon component
    effectId: string; // Identifier for logic
    oneTime?: boolean; // If true, it's a permanent upgrade
}

export interface AIConfig {
    active: boolean;
    role: 'FORTRESS' | 'REPAIR' | 'RANDOM';
    budget: 'LIMITED' | 'INFINITE';
    speed: 'SLOW' | 'FAST';
}

export interface GraphicsSettings {
    particles: 'LOW' | 'HIGH';
    shake: boolean;
    bloom: boolean;
    lighting: 'FLAT' | 'DYNAMIC';
    shadows: boolean;
    crt: boolean;
}