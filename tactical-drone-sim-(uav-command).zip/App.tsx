import React, { useState, useEffect, useCallback, useRef } from 'react';
import RadarMap from './components/RadarMap';
import { Drone, Defense, Vector2, ToolMode, DroneType, LogEntry, ViewState, GameMode, Infrastructure, InfrastructureType, Medal, KeyBindings, KeyAction, ShopCategory, ShopItem, AIConfig, GraphicsSettings } from './types';
import { INITIAL_SPAWN, INITIAL_TARGET, GAME_WIDTH, GAME_HEIGHT, AA_GUN_HEALTH, SAM_HEALTH, FLAK_HEALTH, INFRA_POWER_HEALTH, INFRA_FACTORY_HEALTH, INFRA_COMMAND_HEALTH, INFRA_RADAR_HEALTH, INFRA_JAMMER_HEALTH, INFRA_FUEL_HEALTH, DRONE_TURBO_COST, DRONE_STEALTH_COST, MEDAL_LIST, SHOP_ITEMS_LIST, SCOUT_RETURN_REWARD } from './constants';
import { generateMissionScenario } from './services/geminiService';
import { Activity, X, Zap, Bomb, ScanEye, Plane, Trophy, Settings, LogOut, Factory, Radio, Coins, Rocket, ShoppingCart, CreditCard, ShieldCheck, Moon, Bot, Crosshair, Monitor, Trash2, Ghost, Sun, CloudRain, Lightbulb, Skull, Eye, Target, Loader2, CheckCircle, Battery, Wifi, Signal } from 'lucide-react';

const DEFAULT_BINDINGS: KeyBindings = {
    LAUNCH: 'Space',
    TYPE_ATTACK: 'Digit1',
    TYPE_SCOUT: 'Digit2',
    TYPE_TURBO: 'Digit3',
    PAUSE: 'Escape',
    TOOL_TARGET: 'KeyT',
    TOOL_DELETE: 'Delete',
    TOGGLE_FOG: 'KeyF'
};

const formatKey = (code: string) => {
    if (!code) return 'NONE';
    if (code.startsWith('Key')) return code.replace('Key', '');
    if (code.startsWith('Digit')) return code.replace('Digit', '');
    return code.toUpperCase();
};

const App: React.FC = () => {
  // --- STATE ---
  const [view, setView] = useState<ViewState>(ViewState.MENU);
  const [gameMode, setGameMode] = useState<GameMode>(GameMode.SANDBOX);
  const [isGameActive, setIsGameActive] = useState(false); 
  
  // Settings & Shop State
  const [showSettings, setShowSettings] = useState(false);
  const [showShop, setShowShop] = useState(false);
  const [showExtraModes, setShowExtraModes] = useState(false);
  const [shopCategory, setShopCategory] = useState<ShopCategory>('FINANCE');
  const [purchaseStatus, setPurchaseStatus] = useState<'IDLE' | 'PROCESSING' | 'SUCCESS'>('IDLE');
  
  const [settings, setSettings] = useState<GraphicsSettings>({
      crt: true,
      particles: 'HIGH',
      shake: true,
      bloom: true,
      lighting: 'DYNAMIC',
      shadows: true
  });
  const [settingsTab, setSettingsTab] = useState<'GRAPHICS' | 'MANUAL' | 'MEDALS' | 'CONTROLS'>('GRAPHICS');
  
  // Sandbox AI State
  const [showBotConfig, setShowBotConfig] = useState(false);
  const [sandboxAI, setSandboxAI] = useState<AIConfig>({
      active: false,
      role: 'FORTRESS',
      budget: 'LIMITED',
      speed: 'SLOW'
  });

  // Hotkeys State
  const [hotkeysEnabled, setHotkeysEnabled] = useState(() => localStorage.getItem('shaher_hotkeys') === 'true');
  const [keyBindings, setKeyBindings] = useState<KeyBindings>(() => {
      const saved = localStorage.getItem('shaher_keybindings');
      return saved ? JSON.parse(saved) : DEFAULT_BINDINGS;
  });
  const [listeningFor, setListeningFor] = useState<KeyAction | null>(null);

  // Persist Settings
  useEffect(() => { localStorage.setItem('shaher_hotkeys', String(hotkeysEnabled)); }, [hotkeysEnabled]);
  useEffect(() => { localStorage.setItem('shaher_keybindings', JSON.stringify(keyBindings)); }, [keyBindings]);

  // Progression State (Persistent)
  const [credits, setCredits] = useState(0);
  const [medals, setMedals] = useState<Medal[]>(MEDAL_LIST);
  const [unlockedTech, setUnlockedTech] = useState<Set<string>>(new Set());

  // Tactical Support State (Temporary)
  const [activeSupport, setActiveSupport] = useState({
      emp: false,
      scan: false
  });

  const [drones, setDrones] = useState<Drone[]>([]);
  const [defenses, setDefenses] = useState<Defense[]>([]);
  const [infrastructure, setInfrastructure] = useState<Infrastructure[]>([]);
  const [target, setTarget] = useState<Vector2>(INITIAL_TARGET);
  const [spawnPoints, setSpawnPoints] = useState<Vector2[]>([INITIAL_SPAWN]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  
  const [toolMode, setToolMode] = useState<ToolMode>(ToolMode.SET_TARGET);
  const [activeDefenseType, setActiveDefenseType] = useState<'SAM'|'AA_GUN'|'FLAK'>('AA_GUN');
  const [activeInfraType, setActiveInfraType] = useState<InfrastructureType>('POWER_PLANT');
  const [spawnDroneType, setSpawnDroneType] = useState<DroneType>('ATTACK');
  const [fogEnabled, setFogEnabled] = useState(true);

  // AI Bot Logic Loop
  useEffect(() => {
      if (!isGameActive || gameMode !== GameMode.SANDBOX || !sandboxAI.active) return;

      const interval = setInterval(() => {
          if (Math.random() > (sandboxAI.speed === 'FAST' ? 0.3 : 0.7)) {
             // AI Action
             const randX = 200 + Math.random() * (GAME_WIDTH - 400);
             const randY = 100 + Math.random() * (GAME_HEIGHT - 200);
             const pos = { x: randX, y: randY };

             if (sandboxAI.role === 'FORTRESS' || sandboxAI.role === 'RANDOM') {
                  if (Math.random() > 0.5) {
                      const types: Defense['type'][] = ['AA_GUN', 'FLAK', 'SAM'];
                      const type = types[Math.floor(Math.random() * types.length)];
                      setDefenses(prev => [...prev, {
                          id: Math.random().toString(),
                          pos,
                          range: 0, cooldown: 0, lastFired: 0, type, angle: 0, revealed: true,
                          health: 100, maxHealth: 100
                      }]);
                      addLog("AI Bot constructed defense unit.", "warning");
                  }
             }
             
             if (sandboxAI.role === 'FORTRESS') {
                 // Build Power Plants occasionally
                 if (Math.random() > 0.8) {
                     setInfrastructure(prev => [...prev, {
                         id: Math.random().toString(),
                         type: 'POWER_PLANT', pos, health: 100, maxHealth: 100, revealed: true, destroyed: false
                     }]);
                 }
             }
          }
      }, 2000);

      return () => clearInterval(interval);
  }, [isGameActive, gameMode, sandboxAI]);

  const addLog = (message: string, type: 'info' | 'success' | 'danger' | 'warning' = 'info') => {
    const MAX_MSG_LEN = 80;
    const cleanMessage = message.length > MAX_MSG_LEN ? message.substring(0, MAX_MSG_LEN) + '...' : message;
    setLogs(prev => [{ id: Math.random().toString(), time: new Date().toLocaleTimeString(), message: cleanMessage, type }, ...prev].slice(0, 5));
  };

  const unlockMedal = (id: string) => {
      setMedals(prev => {
          const medal = prev.find(m => m.id === id);
          if (medal && !medal.unlocked) {
              addLog(`MEDAL UNLOCKED: ${medal.name}`, 'success');
              return prev.map(m => m.id === id ? { ...m, unlocked: true } : m);
          }
          return prev;
      });
  };

  const handleInfrastructureCleanup = (id: string) => {
      setInfrastructure(prev => prev.filter(i => i.id !== id));
      // No log needed for cleanup, it's automatic
  };

  const startGame = (mode: GameMode) => {
    setGameMode(mode);
    setView(ViewState.GAME);
    setIsGameActive(true);
    setShowExtraModes(false);
    setDrones([]);
    setLogs([]);
    
    // Initial Setup based on Mode
    if (mode === GameMode.SANDBOX) {
        setDefenses([]);
        setInfrastructure([]);
        setTarget({ x: GAME_WIDTH - 200, y: GAME_HEIGHT / 2 });
        setFogEnabled(false);
        setToolMode(ToolMode.PLACE_DEFENSE); // Default tool
    } else if (mode === GameMode.BASE_DEFENSE) {
        // Player defends Spawn Points from AI Drones
        setDefenses([]); // Player builds them
        setInfrastructure([]);
        setFogEnabled(false);
        setToolMode(ToolMode.PLACE_DEFENSE);
        addLog("DEFEND THE BASES! Enemy drones inbound.", "danger");
    } else if (mode === GameMode.NIGHT_OPS) {
        setDefenses([{
            id: '1', pos: { x: GAME_WIDTH/2, y: GAME_HEIGHT/2 },
            range: 0, cooldown: 0, lastFired: 0, type: 'FLAK', angle: 0, revealed: false, health: 100, maxHealth: 100
        }]);
        setInfrastructure([]);
        setFogEnabled(true);
        setToolMode(ToolMode.SET_TARGET);
        setSettings(s => ({...s, bloom: true })); // Auto set environment
        addLog("NIGHT OPS: Low visibility. Use Thermal Optics.", "warning");
    } else if (mode === GameMode.REALISTIC) {
        setDefenses([{
             id: '1', pos: { x: 600, y: 400 },
             range: 0, cooldown: 0, lastFired: 0, type: 'SAM', angle: 0, revealed: false, health: 200, maxHealth: 200
        }]);
        setInfrastructure([{
            id: 'cc-1', type: 'COMMAND_CENTER', pos: {x: 700, y: 400}, health: 300, maxHealth: 300, revealed: false, destroyed: false
        }]);
        setFogEnabled(true);
        setToolMode(ToolMode.SET_TARGET);
        addLog("REALISTIC MODE: Eliminate Command Center.", "info");
    } else {
        // Default scenarios (Campaign / Attack)
        setDefenses([]);
        setInfrastructure([]);
        setFogEnabled(true);
        setToolMode(ToolMode.SET_TARGET);
        
        // Use Gemini to generate mission
        addLog("Requesting tactical data...", 'info');
        generateMissionScenario('Medium')
            .then(mission => {
                 setTarget(mission.target);
                 setDefenses(mission.defenses.map((d, i) => ({
                     id: `gen-${i}`,
                     pos: d,
                     range: 0, cooldown: 0, lastFired: 0, 
                     type: i % 2 === 0 ? 'SAM' : 'AA_GUN', 
                     angle: 0, 
                     revealed: false, 
                     health: i % 2 === 0 ? SAM_HEALTH : AA_GUN_HEALTH, 
                     maxHealth: i % 2 === 0 ? SAM_HEALTH : AA_GUN_HEALTH
                 })));
                 addLog(`Mission: ${mission.name}`, 'warning');
                 addLog(String(mission.briefing), 'info');
            })
            .catch((err: any) => {
                 const msg = err instanceof Error ? err.message : String(err);
                 addLog(`Mission fail: ${msg}`, 'danger');
            });
    }
  };

  const handleShopPurchase = (item: ShopItem) => {
      if (item.currency === 'CREDITS') {
          if (credits >= item.cost) {
              setCredits(prev => prev - item.cost);
              applyShopEffect(item);
              addLog(`Purchased: ${item.name}`, 'success');
          } else {
              addLog("Insufficient Credits!", "danger");
          }
      } else {
          // Fake Real Money Purchase with Animation
          setPurchaseStatus('PROCESSING');
          setTimeout(() => {
              setPurchaseStatus('SUCCESS');
              applyShopEffect(item);
              setTimeout(() => {
                  setPurchaseStatus('IDLE');
                  addLog(`Transaction Complete: ${item.name}`, 'success');
              }, 2000);
          }, 1500);
      }
  };

  const applyShopEffect = (item: ShopItem) => {
      if (item.effectId === 'add_1000') setCredits(c => c + 1000);
      if (item.effectId === 'add_6000') setCredits(c => c + 6000);
      if (item.effectId === 'add_15000') setCredits(c => c + 15000);
      if (item.effectId === 'add_50000') setCredits(c => c + 50000);
      
      if (item.effectId === 'emp_15s') {
          setActiveSupport(prev => ({ ...prev, emp: true }));
          setTimeout(() => setActiveSupport(prev => ({ ...prev, emp: false })), 15000);
      }
      if (item.effectId === 'reveal_30s') {
          setActiveSupport(prev => ({ ...prev, scan: true }));
          setTimeout(() => setActiveSupport(prev => ({ ...prev, scan: false })), 30000);
      }
      if (item.effectId === 'add_5_drones') {
           // Add 5 random drones
           const newDrones: Drone[] = [];
           for(let i=0; i<5; i++) {
               newDrones.push({
                   id: Math.random().toString(),
                   type: 'ATTACK',
                   pos: { ...spawnPoints[0] },
                   velocity: { x: 0, y: 0 },
                   angle: 0, target: null, active: true, trail: []
               });
           }
           setDrones(prev => [...prev, ...newDrones]);
      }
      if (item.effectId === 'destroy_random') {
          if (defenses.length > 0) {
              const target = defenses[Math.floor(Math.random() * defenses.length)];
              setDefenses(prev => prev.filter(d => d.id !== target.id));
              addLog(`Airstrike confirmed on ${target.type}`, 'success');
          }
      }
      
      // Tech Upgrades
      if (item.category === 'TECH' && item.oneTime) {
          setUnlockedTech(prev => new Set(prev).add(item.effectId));
      }
  };

  const handleDroneReturned = useCallback((type: DroneType) => {
      if (gameMode === GameMode.SANDBOX) return; 

      let reward = 0;
      if (type === 'SCOUT') {
          reward = SCOUT_RETURN_REWARD;
      } else if (type === 'TURBO') {
          reward = Math.floor(DRONE_TURBO_COST / 2);
      } else if (type === 'STEALTH') {
          reward = Math.floor(DRONE_STEALTH_COST / 2);
      }
      
      if (reward > 0) {
          setCredits(prev => prev + reward);
          addLog(`Unit Retrieved: +${reward} CR`, 'success');
      }
  }, [gameMode]);

  // CORE LAUNCH FUNCTION
  const launchDrone = useCallback(() => {
        const cost = spawnDroneType === 'TURBO' ? DRONE_TURBO_COST : (spawnDroneType === 'STEALTH' ? DRONE_STEALTH_COST : 0);
        
        if (gameMode !== GameMode.SANDBOX) {
            if (credits < cost) {
                addLog(`Insufficient funds! Need ${cost} CR`, 'danger');
                return;
            }
            if (cost > 0) setCredits(c => c - cost);
        }

        // Pick a random spawn point if multiple exist
        const spawnPoint = spawnPoints[Math.floor(Math.random() * spawnPoints.length)];
        const newDrone: Drone = {
            id: Math.random().toString(),
            type: spawnDroneType,
            pos: { ...spawnPoint },
            velocity: { x: 0, y: 0 },
            angle: 0,
            target: null,
            active: true,
            trail: []
        };
        setDrones(prev => [...prev, newDrone]);
        addLog(`${spawnDroneType} Drone Launched`, 'info');
  }, [spawnDroneType, gameMode, credits, spawnPoints]);

  // Key binding listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
        if (listeningFor) {
            e.preventDefault();
            setKeyBindings(prev => ({ ...prev, [listeningFor]: e.code }));
            setListeningFor(null);
            return;
        }

        if (!hotkeysEnabled) return;

        if (e.code === keyBindings.PAUSE) {
            if (view === ViewState.GAME) setIsGameActive(prev => !prev);
        }
        
        if (!isGameActive || view !== ViewState.GAME) return;

        if (e.code === keyBindings.LAUNCH) {
            launchDrone();
        }
        if (e.code === keyBindings.TYPE_ATTACK) setSpawnDroneType('ATTACK');
        if (e.code === keyBindings.TYPE_SCOUT) setSpawnDroneType('SCOUT');
        if (e.code === keyBindings.TYPE_TURBO) setSpawnDroneType('TURBO');
        if (e.code === keyBindings.TOOL_TARGET) setToolMode(ToolMode.SET_TARGET);
        if (e.code === keyBindings.TOOL_DELETE) setToolMode(ToolMode.DELETE);
        if (e.code === keyBindings.TOGGLE_FOG) setFogEnabled(prev => !prev);
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [view, isGameActive, keyBindings, hotkeysEnabled, listeningFor, launchDrone]);

  const handleMainMenu = () => {
    setView(ViewState.MENU);
    setIsGameActive(false);
    setShowSettings(false);
    setShowShop(false);
  };

  const renderSettingsContent = () => {
      switch(settingsTab) {
          case 'GRAPHICS': return (
             <div className="space-y-4">
                  <div className="flex justify-between items-center">
                      <span>CRT Scanlines</span>
                      <button onClick={() => setSettings(s => ({...s, crt: !s.crt}))} className={`px-3 py-1 rounded ${settings.crt ? 'bg-green-600' : 'bg-red-600'}`}>{settings.crt ? 'ON' : 'OFF'}</button>
                  </div>
                  <div className="flex justify-between items-center">
                      <span>Screen Shake</span>
                      <button onClick={() => setSettings(s => ({...s, shake: !s.shake}))} className={`px-3 py-1 rounded ${settings.shake ? 'bg-green-600' : 'bg-red-600'}`}>{settings.shake ? 'ON' : 'OFF'}</button>
                  </div>
                  <div className="flex justify-between items-center">
                      <span>Particles</span>
                      <button onClick={() => setSettings(s => ({...s, particles: s.particles === 'HIGH' ? 'LOW' : 'HIGH'}))} className="px-3 py-1 rounded bg-blue-600">{settings.particles}</button>
                  </div>
                  <hr className="border-slate-700 my-2"/>
                  <div className="flex justify-between items-center">
                      <span className="flex items-center gap-2"><Zap size={16} className="text-yellow-400"/> Bloom (Glow)</span>
                      <button onClick={() => setSettings(s => ({...s, bloom: !s.bloom}))} className={`px-3 py-1 rounded ${settings.bloom ? 'bg-green-600' : 'bg-slate-700'}`}>{settings.bloom ? 'ON' : 'OFF'}</button>
                  </div>
                  <div className="flex justify-between items-center">
                      <span className="flex items-center gap-2"><Moon size={16} className="text-indigo-400"/> Shadows</span>
                      <button onClick={() => setSettings(s => ({...s, shadows: !s.shadows}))} className={`px-3 py-1 rounded ${settings.shadows ? 'bg-green-600' : 'bg-slate-700'}`}>{settings.shadows ? 'ON' : 'OFF'}</button>
                  </div>
                   <div className="flex justify-between items-center">
                      <span className="flex items-center gap-2"><Lightbulb size={16} className="text-orange-400"/> Lighting</span>
                      <div className="flex gap-1">
                           <button onClick={() => setSettings(s => ({...s, lighting: 'FLAT'}))} className={`px-2 py-1 rounded text-xs ${settings.lighting === 'FLAT' ? 'bg-blue-600' : 'bg-slate-700'}`}>FLAT</button>
                           <button onClick={() => setSettings(s => ({...s, lighting: 'DYNAMIC'}))} className={`px-2 py-1 rounded text-xs ${settings.lighting === 'DYNAMIC' ? 'bg-blue-600' : 'bg-slate-700'}`}>DYN</button>
                      </div>
                  </div>
             </div>
          );
          case 'CONTROLS': return (
             <div className="space-y-2 h-64 overflow-y-auto no-scrollbar">
                 <div className="flex justify-between items-center mb-4">
                     <span>Enable Hotkeys</span>
                     <button onClick={() => setHotkeysEnabled(!hotkeysEnabled)} className={`px-3 py-1 rounded ${hotkeysEnabled ? 'bg-green-600' : 'bg-red-600'}`}>{hotkeysEnabled ? 'ON' : 'OFF'}</button>
                 </div>
                 {Object.entries(keyBindings).map(([action, key]) => (
                     <div key={action} className="flex justify-between items-center text-sm border-b border-slate-700 pb-1">
                         <span>{action.replace('TYPE_', 'SELECT ').replace('TOOL_', 'TOOL: ')}</span>
                         <button 
                            onClick={() => setListeningFor(action as KeyAction)}
                            className={`px-2 py-1 rounded min-w-[80px] text-center ${listeningFor === action ? 'bg-yellow-600 animate-pulse' : 'bg-slate-700'}`}
                         >
                             {listeningFor === action ? 'PRESS KEY' : formatKey(key)}
                         </button>
                     </div>
                 ))}
             </div>
          );
          case 'MEDALS': return (
             <div className="grid grid-cols-1 gap-2 h-64 overflow-y-auto no-scrollbar">
                 {medals.map(m => (
                     <div key={m.id} className={`flex items-center gap-3 p-2 border ${m.unlocked ? 'border-yellow-500/50 bg-yellow-900/20' : 'border-slate-700 bg-slate-800/50'} rounded`}>
                         <Trophy size={16} className={m.unlocked ? 'text-yellow-400' : 'text-slate-600'} />
                         <div>
                             <div className={`text-sm font-bold ${m.unlocked ? 'text-yellow-200' : 'text-slate-500'}`}>{m.name}</div>
                             <div className="text-xs text-slate-400">{m.description}</div>
                         </div>
                     </div>
                 ))}
             </div>
          );
          case 'MANUAL': return (
             <div className="text-xs text-slate-300 space-y-2 h-64 overflow-y-auto no-scrollbar p-2 bg-slate-950 rounded border border-slate-700">
                 <p><strong className="text-green-400">ATTACK Drone:</strong> Balanced. Cheap.</p>
                 <p><strong className="text-blue-400">SCOUT Drone:</strong> Fast. Weak. Huge vision.</p>
                 <p><strong className="text-purple-400">TURBO Drone:</strong> Very Fast. Low agility.</p>
                 <p><strong className="text-indigo-400">STEALTH Drone:</strong> Invisible to radar until close.</p>
                 <hr className="border-slate-700"/>
                 <p><strong className="text-yellow-400">FLAK:</strong> Area damage. Deadly to groups.</p>
                 <p><strong className="text-red-400">SAM:</strong> Long range homing missiles.</p>
                 <p><strong className="text-orange-400">AA GUN:</strong> Rapid fire. Short range.</p>
                 <hr className="border-slate-700"/>
                 <p><strong>RADAR:</strong> Clears Fog of War.</p>
                 <p><strong>POWER PLANT:</strong> Powers nearby defenses.</p>
             </div>
          );
      }
  }

  return (
    <div className={`w-full h-full relative flex flex-col overflow-hidden ${settings.crt ? 'bg-slate-900' : 'bg-gray-900'}`}>
      {settings.crt && <div className="scanlines pointer-events-none" />}
      
      {/* --- HEADER --- */}
      <header className="h-12 bg-slate-950 border-b border-slate-800 flex items-center justify-between px-4 shrink-0 z-10">
        <div className="flex items-center gap-2 text-slate-100 font-bold">
            <Plane className="text-blue-500" size={20} />
            <span className="hidden md:inline">UAV TACTICAL SIM</span>
            <span className="md:hidden">UAV SIM</span>
        </div>
        
        {/* Fake System Status for Mobile Feel */}
        <div className="hidden md:flex items-center gap-4 text-xs text-slate-500">
            <span className="flex items-center gap-1"><Signal size={12}/> NET_OK</span>
            <span className="flex items-center gap-1"><Battery size={12}/> 98%</span>
        </div>
        
        {view === ViewState.GAME && (
            <div className="flex items-center gap-4 text-xs md:text-sm">
                <div className="flex items-center gap-1 text-yellow-400">
                    <Coins size={14}/>
                    <span>{credits} CR</span>
                </div>
                <div className={`flex items-center gap-1 ${isGameActive ? 'text-green-500' : 'text-yellow-500'}`}>
                    <Activity size={14} />
                    <span>{isGameActive ? 'LIVE' : 'PAUSED'}</span>
                </div>
            </div>
        )}

        <div className="flex items-center gap-2">
            {view === ViewState.MENU && (
                <button onClick={() => setShowSettings(true)} className="p-2 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors">
                    <Settings size={20} />
                </button>
            )}
            {view === ViewState.GAME && (
                <button onClick={() => setIsGameActive(!isGameActive)} className="p-2 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors">
                    {isGameActive ? <Settings size={20} /> : <Settings size={20} />}
                </button>
            )}
        </div>
      </header>

      {/* --- MAIN CONTENT --- */}
      <main className="flex-1 relative overflow-hidden">
        
        {view === ViewState.MENU && (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 z-20 bg-[url('https://images.unsplash.com/photo-1474557157379-8aa74a6ef541?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center">
            <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm" />
            
            <div className="relative w-full max-w-md space-y-3 animate-in fade-in zoom-in duration-500">
                <h1 className="text-4xl font-black text-center text-white mb-8 tracking-tighter drop-shadow-lg">
                    SKY <span className="text-blue-500">COMMAND</span>
                </h1>

                <button onClick={() => startGame(GameMode.SANDBOX)} className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded text-lg shadow-lg shadow-blue-900/20 transition-all transform hover:scale-[1.02]">
                    SANDBOX
                </button>
                <button onClick={() => startGame(GameMode.ATTACK)} className="w-full py-4 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded text-lg border border-slate-700 transition-all transform hover:scale-[1.02]">
                    CAMPAIGN
                </button>
                <button onClick={() => setShowExtraModes(true)} className="w-full py-4 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded text-lg border border-slate-700 transition-all transform hover:scale-[1.02]">
                    EXTRA OPS
                </button>
                <button onClick={() => setShowShop(true)} className="w-full py-3 bg-emerald-900/50 hover:bg-emerald-800/50 text-emerald-200 font-bold rounded border border-emerald-800 transition-all flex items-center justify-center gap-2">
                    <ShoppingCart size={18} /> SUPPLY LOGISTICS
                </button>
            </div>
          </div>
        )}

        {view === ViewState.GAME && (
          <div className="absolute inset-0 flex flex-col">
              <RadarMap 
                drones={drones}
                setDrones={setDrones}
                defenses={defenses}
                setDefenses={setDefenses}
                infrastructure={infrastructure}
                setInfrastructure={setInfrastructure}
                target={target}
                setTarget={setTarget}
                spawnPoints={spawnPoints}
                setSpawnPoints={setSpawnPoints}
                toolMode={toolMode}
                onLog={addLog}
                isRunning={isGameActive}
                activeDefenseType={activeDefenseType}
                activeInfraType={activeInfraType}
                fogEnabled={fogEnabled}
                gameMode={gameMode}
                onTargetDestroyed={() => unlockMedal('first_blood')}
                onDefenseDestroyed={(type: string) => {
                    if (gameMode === GameMode.BASE_DEFENSE) {
                        // Killing drones gives money in Base Defense
                        setCredits(c => c + 10);
                        return;
                    }
                    setCredits(c => c + 25);
                    if (type !== 'AA_GUN') unlockMedal('first_blood');
                }}
                qualitySettings={settings}
                activeSupport={activeSupport}
                upgrades={unlockedTech}
                onDroneReturned={handleDroneReturned}
                onInfrastructureCleanup={handleInfrastructureCleanup}
              />
              
              {/* Logs Overlay */}
              <div className="absolute top-16 right-4 w-64 flex flex-col gap-1 pointer-events-none z-30 opacity-90">
                {logs.map(log => (
                    <div key={log.id} className={`text-[10px] px-2 py-1 rounded backdrop-blur-sm border-l-2 shadow-sm animate-in slide-in-from-right-5 fade-in duration-300 ${
                        log.type === 'success' ? 'bg-green-900/80 border-green-500 text-green-100' :
                        log.type === 'danger' ? 'bg-red-900/80 border-red-500 text-red-100' :
                        log.type === 'warning' ? 'bg-yellow-900/80 border-yellow-500 text-yellow-100' :
                        'bg-blue-900/80 border-blue-500 text-blue-100'
                    }`}>
                        <span className="opacity-50 mr-2 font-mono">[{log.time.split(' ')[0]}]</span>
                        <span className="break-words leading-tight">{log.message}</span>
                    </div>
                ))}
              </div>

              {/* GAME OVERLAY UI (Tools) */}
              <div className="absolute bottom-0 left-0 right-0 bg-slate-950/90 backdrop-blur border-t border-slate-800 p-2 pb-6 md:pb-2 pointer-events-auto">
                 {/* Mobile Scroll Container */}
                 <div className="max-w-4xl mx-auto flex items-center gap-2 overflow-x-auto no-scrollbar px-2">
                     
                     {/* Main Action Button */}
                     {gameMode !== GameMode.BASE_DEFENSE && (
                         <button 
                            onClick={launchDrone}
                            className="h-14 w-14 shrink-0 md:w-16 md:h-16 rounded-full bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center shadow-lg shadow-blue-900/50 active:scale-95 transition-transform"
                         >
                             <Plane className="rotate-45" size={28} />
                         </button>
                     )}

                     {/* Drone Type Selectors */}
                     {gameMode !== GameMode.BASE_DEFENSE && (
                         <div className="flex gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800 shrink-0">
                             {(['ATTACK', 'SCOUT', 'TURBO', 'STEALTH'] as DroneType[]).map(type => (
                                 <button
                                    key={type}
                                    onClick={() => setSpawnDroneType(type)}
                                    className={`px-3 py-2 rounded text-xs font-bold transition-colors flex flex-col md:flex-row items-center gap-1 min-w-[60px] md:min-w-0 ${spawnDroneType === type ? 'bg-slate-700 text-white shadow' : 'text-slate-500 hover:text-slate-300'}`}
                                 >
                                     {type === 'TURBO' ? <Rocket size={16}/> : type === 'STEALTH' ? <Ghost size={16}/> : type === 'SCOUT' ? <ScanEye size={16}/> : <Crosshair size={16}/>}
                                     <span className="text-[10px] md:text-xs">{type}</span>
                                 </button>
                             ))}
                         </div>
                     )}
                    
                     {/* Build Tools (Sandbox / Defense) */}
                     {(gameMode === GameMode.SANDBOX || gameMode === GameMode.BASE_DEFENSE || gameMode === GameMode.REALISTIC || gameMode === GameMode.NIGHT_OPS) && (
                         <div className="flex gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800 shrink-0">
                             {gameMode !== GameMode.NIGHT_OPS && gameMode !== GameMode.REALISTIC && (
                                <>
                                    <button onClick={() => setToolMode(ToolMode.PLACE_DEFENSE)} className={`p-3 rounded ${toolMode === ToolMode.PLACE_DEFENSE ? 'bg-red-900/50 text-red-200' : 'text-slate-500'}`}><ShieldCheck size={20}/></button>
                                    <button onClick={() => setToolMode(ToolMode.PLACE_INFRASTRUCTURE)} className={`p-3 rounded ${toolMode === ToolMode.PLACE_INFRASTRUCTURE ? 'bg-yellow-900/50 text-yellow-200' : 'text-slate-500'}`}><Factory size={20}/></button>
                                </>
                             )}
                             <button onClick={() => setToolMode(ToolMode.SET_TARGET)} className={`p-3 rounded ${toolMode === ToolMode.SET_TARGET ? 'bg-blue-900/50 text-blue-200' : 'text-slate-500'}`}><Crosshair size={20}/></button>
                             <button onClick={() => setToolMode(ToolMode.DELETE)} className={`p-3 rounded ${toolMode === ToolMode.DELETE ? 'bg-red-600 text-white' : 'text-slate-500'}`}><Trash2 size={20}/></button>
                         </div>
                     )}
                     
                     {/* Toggle Sub-Types (Only visible if relevant tool selected) */}
                     {toolMode === ToolMode.PLACE_DEFENSE && (gameMode === GameMode.SANDBOX || gameMode === GameMode.BASE_DEFENSE) && (
                         <div className="flex gap-1 shrink-0">
                             {(['AA_GUN', 'FLAK', 'SAM'] as const).map(t => (
                                 <button key={t} onClick={() => setActiveDefenseType(t)} className={`text-[10px] px-3 py-2 rounded border font-bold ${activeDefenseType === t ? 'border-red-500 bg-red-900/20 text-red-200' : 'border-slate-700 text-slate-500'}`}>{t}</button>
                             ))}
                         </div>
                     )}
                     {toolMode === ToolMode.PLACE_INFRASTRUCTURE && (gameMode === GameMode.SANDBOX || gameMode === GameMode.BASE_DEFENSE) && (
                         <div className="flex gap-1 shrink-0">
                             {(['POWER_PLANT', 'RADAR', 'JAMMER', 'COMMAND_CENTER', 'FUEL_DEPOT'] as const).map(t => (
                                 <button key={t} onClick={() => setActiveInfraType(t)} className={`text-[10px] px-3 py-2 whitespace-nowrap rounded border font-bold ${activeInfraType === t ? 'border-yellow-500 bg-yellow-900/20 text-yellow-200' : 'border-slate-700 text-slate-500'}`}>{t.replace('_', ' ')}</button>
                             ))}
                         </div>
                     )}

                     {/* Sandbox AI Toggle */}
                     {gameMode === GameMode.SANDBOX && (
                        <button onClick={() => setShowBotConfig(true)} className="flex items-center gap-1 px-3 py-2 bg-indigo-900/50 text-indigo-300 rounded border border-indigo-800 hover:bg-indigo-800/50 shrink-0">
                            <Bot size={20} />
                            <span className="text-xs font-bold hidden md:inline">AI BOT</span>
                        </button>
                     )}
                 </div>
              </div>
          </div>
        )}

      </main>

      {/* --- MODALS --- */}

      {/* EXTRA OPS MODAL */}
      {showExtraModes && (
          <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-200">
              <div className="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
                  <div className="p-4 border-b border-slate-800 bg-slate-950 flex justify-between items-center shrink-0">
                      <h2 className="text-xl font-bold text-white flex items-center gap-2">
                          <Target className="text-red-500" /> SPECIAL OPERATIONS
                      </h2>
                      <button onClick={() => setShowExtraModes(false)} className="text-slate-400 hover:text-white"><X /></button>
                  </div>
                  <div className="p-6 overflow-y-auto grid grid-cols-1 md:grid-cols-3 gap-4">
                      <button onClick={() => startGame(GameMode.BASE_DEFENSE)} className="group relative p-6 bg-slate-800/50 border border-slate-700 hover:border-blue-500 hover:bg-slate-800 rounded-lg transition-all flex flex-col items-center text-center gap-3">
                          <ShieldCheck size={40} className="text-blue-500 group-hover:scale-110 transition-transform" />
                          <div className="font-bold text-white">BASE DEFENSE</div>
                          <div className="text-xs text-slate-400">Protect your spawn points from incoming enemy drone waves.</div>
                      </button>
                      <button onClick={() => startGame(GameMode.NIGHT_OPS)} className="group relative p-6 bg-slate-800/50 border border-slate-700 hover:border-purple-500 hover:bg-slate-800 rounded-lg transition-all flex flex-col items-center text-center gap-3">
                          <Moon size={40} className="text-purple-500 group-hover:scale-110 transition-transform" />
                          <div className="font-bold text-white">NIGHT OPS</div>
                          <div className="text-xs text-slate-400">Stealth mission with limited visibility. Thermal optics recommended.</div>
                      </button>
                      <button onClick={() => startGame(GameMode.REALISTIC)} className="group relative p-6 bg-slate-800/50 border border-slate-700 hover:border-red-500 hover:bg-slate-800 rounded-lg transition-all flex flex-col items-center text-center gap-3">
                          <Skull size={40} className="text-red-500 group-hover:scale-110 transition-transform" />
                          <div className="font-bold text-white">REALISTIC</div>
                          <div className="text-xs text-slate-400">Hardcore mode. Limited intel, fortified targets. High casualties expected.</div>
                      </button>
                  </div>
              </div>
          </div>
      )}
      
      {/* SETTINGS / PAUSE MENU */}
      {(showSettings || (!isGameActive && view === ViewState.GAME && !showExtraModes && !showShop)) && (
          <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur flex items-center justify-center p-4">
              <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
                  <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-950">
                      <h2 className="text-xl font-bold text-white flex items-center gap-2">
                          <Settings className="text-slate-400"/> SETTINGS
                      </h2>
                      <button onClick={() => { setShowSettings(false); if(view === ViewState.GAME) setIsGameActive(true); }} className="text-slate-400 hover:text-white"><X /></button>
                  </div>
                  
                  {/* Tabs */}
                  <div className="flex border-b border-slate-800">
                      {(['GRAPHICS', 'CONTROLS', 'MEDALS', 'MANUAL'] as const).map(tab => (
                          <button 
                            key={tab}
                            onClick={() => setSettingsTab(tab)}
                            className={`flex-1 py-3 text-xs font-bold transition-colors ${settingsTab === tab ? 'bg-slate-800 text-blue-400 border-b-2 border-blue-500' : 'text-slate-500 hover:text-slate-300'}`}
                          >
                              {tab}
                          </button>
                      ))}
                  </div>

                  <div className="p-6 overflow-y-auto">
                      {renderSettingsContent()}
                  </div>
                  
                  <div className="p-4 border-t border-slate-800 bg-slate-950 flex justify-between">
                      {view === ViewState.GAME && (
                          <button onClick={handleMainMenu} className="flex items-center gap-2 text-red-400 hover:text-red-300 font-bold text-sm">
                              <LogOut size={16} /> ABORT MISSION
                          </button>
                      )}
                      <div className="flex-1" />
                      <button onClick={() => { setShowSettings(false); setShowShop(true); }} className="flex items-center gap-2 text-emerald-400 hover:text-emerald-300 font-bold text-sm mr-4">
                          <ShoppingCart size={16} /> SUPPLY
                      </button>
                      <button onClick={() => { setShowSettings(false); if(view === ViewState.GAME) setIsGameActive(true); }} className="bg-white text-black px-6 py-2 rounded font-bold hover:bg-slate-200">
                          RESUME
                      </button>
                  </div>
              </div>
          </div>
      )}
      
      {/* SHOP / SUPPLY LOGISTICS (REDESIGNED FOR MOBILE) */}
      {showShop && (
          <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-0 md:p-4">
               <div className="w-full max-w-5xl bg-slate-950/90 md:border border-slate-800 shadow-2xl overflow-hidden flex flex-col h-full md:max-h-[95vh] md:h-[800px] relative">
                    {/* Decorative Corner Accents */}
                    <div className="hidden md:block absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-blue-500 pointer-events-none"/>
                    <div className="hidden md:block absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-blue-500 pointer-events-none"/>
                    <div className="hidden md:block absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-blue-500 pointer-events-none"/>
                    <div className="hidden md:block absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-blue-500 pointer-events-none"/>
                    
                    {/* Processing Overlay */}
                    {purchaseStatus !== 'IDLE' && (
                        <div className="absolute inset-0 z-[60] bg-black/90 backdrop-blur flex flex-col items-center justify-center">
                            {purchaseStatus === 'PROCESSING' ? (
                                <div className="flex flex-col items-center animate-pulse">
                                    <div className="relative">
                                        <Loader2 size={64} className="text-blue-500 animate-spin"/>
                                        <Wifi size={24} className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-blue-300"/>
                                    </div>
                                    <div className="text-blue-400 font-mono text-xl mt-4 tracking-widest">CONNECTING BANK...</div>
                                    <div className="text-blue-600 font-mono text-xs mt-2">ENCRYPTED LINK ESTABLISHED</div>
                                </div>
                            ) : (
                                <div className="flex flex-col items-center animate-in zoom-in duration-300">
                                    <div className="relative">
                                        <div className="absolute inset-0 bg-green-500 blur-xl opacity-50 rounded-full"/>
                                        <CheckCircle size={80} className="text-green-500 relative z-10"/>
                                    </div>
                                    <div className="text-green-400 font-mono text-3xl font-bold mt-4 tracking-widest">APPROVED</div>
                                    <div className="text-green-600 font-mono text-sm mt-2">FUNDS TRANSFERRED</div>
                                </div>
                            )}
                        </div>
                    )}

                    <div className="p-4 border-b border-slate-800 bg-slate-950 flex justify-between items-center z-10 shrink-0">
                         <div className="flex items-center gap-3">
                             <div className="p-2 bg-emerald-900/20 rounded border border-emerald-500/30 text-emerald-500">
                                <ShoppingCart size={20} />
                             </div>
                             <div>
                                 <h2 className="text-xl md:text-2xl font-black text-white tracking-tight">SUPPLY LOGISTICS</h2>
                                 <div className="flex items-center gap-4 text-xs font-mono text-slate-500">
                                     <span className="hidden md:inline">AUTH: CMDR_SHAHER</span>
                                     <span className="text-yellow-500">CREDITS: {credits}</span>
                                 </div>
                             </div>
                         </div>
                         <button onClick={() => setShowShop(false)} className="text-slate-500 hover:text-white transition-colors"><X size={28}/></button>
                    </div>

                    <div className="flex flex-col md:flex-row flex-1 overflow-hidden">
                        {/* Sidebar / Topbar for Mobile */}
                        <div className="w-full md:w-60 bg-slate-900/50 border-b md:border-b-0 md:border-r border-slate-800 flex flex-row md:flex-col p-2 md:p-4 gap-2 z-10 overflow-x-auto no-scrollbar shrink-0">
                            <button onClick={() => setShopCategory('FINANCE')} className={`group p-3 md:p-4 rounded-lg text-left text-xs md:text-sm font-bold flex items-center gap-2 md:gap-3 transition-all whitespace-nowrap ${shopCategory === 'FINANCE' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/20' : 'text-slate-400 bg-slate-900 md:bg-transparent hover:bg-slate-800'}`}>
                                <CreditCard size={18} className={shopCategory === 'FINANCE' ? 'text-emerald-200' : 'text-slate-500 group-hover:text-emerald-400'}/> 
                                FINANCE
                            </button>
                            <button onClick={() => setShopCategory('SUPPORT')} className={`group p-3 md:p-4 rounded-lg text-left text-xs md:text-sm font-bold flex items-center gap-2 md:gap-3 transition-all whitespace-nowrap ${shopCategory === 'SUPPORT' ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' : 'text-slate-400 bg-slate-900 md:bg-transparent hover:bg-slate-800'}`}>
                                <Radio size={18} className={shopCategory === 'SUPPORT' ? 'text-blue-200' : 'text-slate-500 group-hover:text-blue-400'}/> 
                                SUPPORT
                            </button>
                            <button onClick={() => setShopCategory('TECH')} className={`group p-3 md:p-4 rounded-lg text-left text-xs md:text-sm font-bold flex items-center gap-2 md:gap-3 transition-all whitespace-nowrap ${shopCategory === 'TECH' ? 'bg-purple-600 text-white shadow-lg shadow-purple-900/20' : 'text-slate-400 bg-slate-900 md:bg-transparent hover:bg-slate-800'}`}>
                                <Monitor size={18} className={shopCategory === 'TECH' ? 'text-purple-200' : 'text-slate-500 group-hover:text-purple-400'}/> 
                                TECH
                            </button>
                        </div>

                        {/* Content Grid */}
                        <div className="flex-1 p-4 md:p-8 overflow-y-auto bg-slate-950 relative">
                             {/* Background Grid Pattern */}
                             <div className="absolute inset-0 opacity-5 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#475569 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
                             
                             <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 relative z-10 pb-8">
                                 {SHOP_ITEMS_LIST.filter(i => i.category === shopCategory).map(item => {
                                     const Icon = item.icon;
                                     const isOwned = item.oneTime && unlockedTech.has(item.effectId);
                                     const canAfford = item.currency === 'USD' ? true : credits >= item.cost;
                                     
                                     let accentColor = 'border-slate-700';
                                     if (shopCategory === 'FINANCE') accentColor = 'hover:border-emerald-500/50';
                                     if (shopCategory === 'SUPPORT') accentColor = 'hover:border-blue-500/50';
                                     if (shopCategory === 'TECH') accentColor = 'hover:border-purple-500/50';

                                     return (
                                         <button 
                                            key={item.id} 
                                            disabled={isOwned || (!canAfford && item.currency !== 'USD')}
                                            onClick={() => handleShopPurchase(item)}
                                            className={`relative group flex flex-col h-full min-h-[160px] bg-slate-900/80 border ${accentColor} rounded-xl p-0 overflow-hidden transition-all duration-300 active:scale-95 ${isOwned ? 'opacity-60 grayscale' : ''}`}
                                         >
                                             {/* Card Header / Icon Area */}
                                             <div className={`h-20 w-full flex items-center justify-center bg-gradient-to-br ${
                                                 shopCategory === 'FINANCE' ? 'from-emerald-900/40 to-slate-900' : 
                                                 shopCategory === 'SUPPORT' ? 'from-blue-900/40 to-slate-900' : 
                                                 'from-purple-900/40 to-slate-900'
                                             }`}>
                                                 <Icon size={32} className={`drop-shadow-lg transition-transform group-hover:scale-110 duration-500 ${
                                                     shopCategory === 'FINANCE' ? 'text-emerald-400' : 
                                                     shopCategory === 'SUPPORT' ? 'text-blue-400' : 
                                                     'text-purple-400'
                                                 }`} />
                                             </div>

                                             {/* Card Body */}
                                             <div className="p-4 flex-1 flex flex-col text-left w-full border-t border-slate-800">
                                                 <h3 className="font-bold text-base text-slate-100 mb-1 group-hover:text-white">{item.name}</h3>
                                                 <p className="text-xs text-slate-400 mb-4 flex-1 leading-relaxed">{item.description}</p>
                                                 
                                                 {/* Price / Action */}
                                                 <div className="mt-auto pt-3 border-t border-slate-800/50 flex justify-between items-center w-full">
                                                     <div className={`text-sm font-mono font-bold ${item.currency === 'USD' ? 'text-emerald-400' : canAfford ? 'text-yellow-400' : 'text-red-400'}`}>
                                                         {item.currency === 'USD' ? `$${item.cost}` : `${item.cost} CR`}
                                                     </div>
                                                     
                                                     {isOwned ? (
                                                         <span className="text-[10px] font-bold bg-slate-800 text-slate-400 px-2 py-1 rounded">OWNED</span>
                                                     ) : (
                                                         <div className={`px-3 py-1.5 rounded text-[10px] font-bold tracking-wide uppercase transition-colors ${
                                                             canAfford ? 'bg-white text-black group-hover:bg-blue-500 group-hover:text-white' : 'bg-slate-800 text-slate-600'
                                                         }`}>
                                                             BUY
                                                         </div>
                                                     )}
                                                 </div>
                                             </div>
                                         </button>
                                     );
                                 })}
                             </div>
                        </div>
                    </div>
               </div>
          </div>
      )}

      {/* BOT CONFIG (Sandbox) */}
      {showBotConfig && (
          <div className="absolute inset-0 z-40 bg-black/60 flex items-center justify-center p-4">
              <div className="bg-slate-900 border border-slate-600 p-6 rounded-lg w-80 shadow-2xl animate-in fade-in zoom-in">
                  <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2"><Bot /> AI CONFIG</h3>
                  
                  <div className="space-y-4">
                      <div className="flex justify-between items-center">
                          <span className="text-sm text-slate-300">Active</span>
                          <button onClick={() => setSandboxAI(s => ({...s, active: !s.active}))} className={`w-12 h-6 rounded-full transition-colors ${sandboxAI.active ? 'bg-green-500' : 'bg-slate-700'}`}>
                              <div className={`w-4 h-4 bg-white rounded-full transform transition-transform ${sandboxAI.active ? 'translate-x-7' : 'translate-x-1'}`} />
                          </button>
                      </div>
                      
                      <div>
                          <label className="text-xs text-slate-500 uppercase font-bold">Role</label>
                          <div className="flex gap-1 mt-1">
                              {(['FORTRESS', 'RANDOM'] as const).map(r => (
                                  <button key={r} onClick={() => setSandboxAI(s => ({...s, role: r}))} className={`flex-1 py-1 text-xs border rounded ${sandboxAI.role === r ? 'bg-blue-900 text-blue-200 border-blue-500' : 'border-slate-700 text-slate-400'}`}>{r}</button>
                              ))}
                          </div>
                      </div>

                      <div>
                          <label className="text-xs text-slate-500 uppercase font-bold">Speed</label>
                          <div className="flex gap-1 mt-1">
                              <button onClick={() => setSandboxAI(s => ({...s, speed: 'SLOW'}))} className={`flex-1 py-1 text-xs border rounded ${sandboxAI.speed === 'SLOW' ? 'bg-slate-700 text-white border-slate-500' : 'border-slate-700 text-slate-500'}`}>SLOW</button>
                              <button onClick={() => setSandboxAI(s => ({...s, speed: 'FAST'}))} className={`flex-1 py-1 text-xs border rounded ${sandboxAI.speed === 'FAST' ? 'bg-red-900 text-red-200 border-red-500' : 'border-slate-700 text-slate-500'}`}>FAST</button>
                          </div>
                      </div>
                  </div>

                  <div className="mt-6 flex justify-end">
                      <button onClick={() => setShowBotConfig(false)} className="bg-white text-black font-bold px-4 py-1 rounded hover:bg-slate-200">DONE</button>
                  </div>
              </div>
          </div>
      )}

    </div>
  );
};

export default App;