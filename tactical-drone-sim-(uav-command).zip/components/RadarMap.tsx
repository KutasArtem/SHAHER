
import React, { useRef, useEffect, useCallback } from 'react';
import { Drone, Defense, Projectile, Explosion, Vector2, ToolMode, Particle, Shockwave, GameMode, FloatingText, Infrastructure, InfrastructureType, DroneType, GraphicsSettings } from '../types';
import { 
  GAME_WIDTH, GAME_HEIGHT, 
  DRONE_ATTACK_SPEED, DRONE_ATTACK_TURN, DRONE_ATTACK_VISION,
  DRONE_SCOUT_SPEED, DRONE_SCOUT_TURN, DRONE_SCOUT_VISION,
  DRONE_TURBO_SPEED, DRONE_TURBO_TURN,
  DRONE_STEALTH_SPEED, DRONE_STEALTH_TURN, DRONE_STEALTH_VISIBILITY,
  AA_GUN_RANGE, AA_GUN_COOLDOWN, AA_GUN_PROJECTILE_SPEED, AA_GUN_ACCURACY, AA_GUN_HEALTH,
  SAM_RANGE, SAM_COOLDOWN, SAM_PROJECTILE_SPEED, SAM_PROJECTILE_ACCEL, SAM_HEALTH,
  FLAK_RANGE, FLAK_COOLDOWN, FLAK_PROJECTILE_SPEED, FLAK_EXPLOSION_RADIUS, FLAK_HEALTH,
  DRONE_DAMAGE,
  INFRA_POWER_HEALTH, INFRA_FACTORY_HEALTH, INFRA_COMMAND_HEALTH, INFRA_RADAR_HEALTH, INFRA_JAMMER_HEALTH, INFRA_FUEL_HEALTH,
  POWER_GRID_RADIUS, JAMMER_RADIUS, RADAR_REVEAL_RADIUS
} from '../constants';

interface RadarMapProps {
  drones: Drone[];
  setDrones: React.Dispatch<React.SetStateAction<Drone[]>>;
  defenses: Defense[];
  setDefenses: React.Dispatch<React.SetStateAction<Defense[]>>;
  infrastructure: Infrastructure[];
  setInfrastructure: React.Dispatch<React.SetStateAction<Infrastructure[]>>;
  target: Vector2;
  setTarget: (v: Vector2) => void;
  spawnPoints: Vector2[];
  setSpawnPoints: React.Dispatch<React.SetStateAction<Vector2[]>>;
  toolMode: ToolMode;
  onLog: (msg: string, type: 'info' | 'success' | 'danger' | 'warning') => void;
  isRunning: boolean;
  activeDefenseType: 'SAM' | 'AA_GUN' | 'FLAK';
  activeInfraType: InfrastructureType;
  fogEnabled: boolean;
  gameMode: GameMode;
  onTargetDestroyed?: () => void;
  onDefenseDestroyed?: (type: string) => void;
  qualitySettings: GraphicsSettings;
  activeSupport: {
      emp: boolean;
      scan: boolean;
  };
  upgrades: Set<string>;
  onDroneReturned: (type: DroneType) => void;
  onInfrastructureCleanup: (id: string) => void;
}

const RadarMap: React.FC<RadarMapProps> = ({
  drones,
  setDrones,
  defenses,
  setDefenses,
  infrastructure,
  setInfrastructure,
  target,
  setTarget,
  spawnPoints,
  setSpawnPoints,
  toolMode,
  onLog,
  isRunning,
  activeDefenseType,
  activeInfraType,
  fogEnabled,
  gameMode,
  onTargetDestroyed,
  onDefenseDestroyed,
  qualitySettings,
  activeSupport,
  upgrades,
  onDroneReturned,
  onInfrastructureCleanup
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>();
  const isDraggingRef = useRef<boolean>(false);
  
  // Physics entities refs
  const projectilesRef = useRef<Projectile[]>([]);
  const explosionsRef = useRef<Explosion[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const shockwavesRef = useRef<Shockwave[]>([]);
  const floatingTextsRef = useRef<FloatingText[]>([]);
  const shakeRef = useRef<number>(0); // Screen shake intensity
  
  // Game loop logic state refs
  const dronesRef = useRef<Drone[]>(drones);
  const defensesRef = useRef<Defense[]>(defenses);
  const infrastructureRef = useRef<Infrastructure[]>(infrastructure);
  const targetRef = useRef<Vector2>(target);
  const spawnPointsRef = useRef<Vector2[]>(spawnPoints);
  
  useEffect(() => { dronesRef.current = drones; }, [drones]);
  useEffect(() => { defensesRef.current = defenses; }, [defenses]);
  useEffect(() => { infrastructureRef.current = infrastructure; }, [infrastructure]);
  useEffect(() => { targetRef.current = target; }, [target]);
  useEffect(() => { spawnPointsRef.current = spawnPoints; }, [spawnPoints]);

  const addShake = (amount: number) => {
      if (!qualitySettings.shake) return;
      shakeRef.current = Math.min(shakeRef.current + amount, 20);
  };

  const spawnFloatingText = (pos: Vector2, text: string, color: string) => {
      floatingTextsRef.current.push({
          id: Math.random().toString(),
          pos: { ...pos },
          text,
          color,
          life: 1.0,
          velocity: { x: (Math.random() - 0.5) * 1, y: -1.5 }
      });
  };

  const spawnExplosion = (pos: Vector2, color: string, radius: number, damage: boolean = false) => {
    addShake(damage ? 5 : 2);
    
    // Main flash
    explosionsRef.current.push({
      id: Math.random().toString(),
      pos: { ...pos },
      radius: 2,
      maxRadius: radius,
      alpha: 1,
      color,
      damage
    });

    // Shockwave
    if (qualitySettings.particles === 'HIGH') {
        shockwavesRef.current.push({
            id: Math.random().toString(),
            pos: { ...pos },
            radius: 10,
            maxRadius: radius * 1.5,
            alpha: 0.8
        });
    }

    // Particles (Sparks & Debris)
    const multiplier = qualitySettings.particles === 'HIGH' ? 1 : 0.3;
    const particleCount = Math.floor((damage ? 15 : 8) * multiplier);

    for(let i=0; i<particleCount; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = Math.random() * (damage ? 5 : 2);
        particlesRef.current.push({
            id: Math.random().toString(),
            pos: { ...pos },
            velocity: { x: Math.cos(angle) * speed, y: Math.sin(angle) * speed },
            life: 1.0,
            decay: 0.02 + Math.random() * 0.03,
            color: damage ? '#fca5a5' : '#fbbf24',
            size: Math.random() * 3 + 1,
            type: damage ? 'DEBRIS' : 'SPARK'
        });
    }
    
    // Smoke
    const smokeCount = qualitySettings.particles === 'HIGH' ? 5 : 2;
    for(let i=0; i<smokeCount; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = Math.random() * 1;
        particlesRef.current.push({
            id: Math.random().toString(),
            pos: { ...pos },
            velocity: { x: Math.cos(angle) * speed, y: Math.sin(angle) * speed },
            life: 1.0,
            decay: 0.01,
            color: '#52525b', // Zinc-600
            size: Math.random() * 5 + 3,
            type: 'SMOKE'
        });
    }
  };

  const distance = (a: Vector2, b: Vector2) => Math.sqrt(Math.pow(b.x - a.x, 2) + Math.pow(b.y - a.y, 2));

  const updatePhysics = () => {
    if (!isRunning) return;
    
    const now = Date.now();

    // Tech Bonuses
    const speedBonus = upgrades.has('tech_speed') ? 1.15 : 1.0;
    const visionBonus = upgrades.has('tech_optics') ? 1.3 : 1.0;

    // Decrease screenshake
    if (shakeRef.current > 0) shakeRef.current *= 0.9;
    if (shakeRef.current < 0.5) shakeRef.current = 0;

    const hasPowerPlants = infrastructureRef.current.some(i => i.type === 'POWER_PLANT');
    const activePowerPlants = infrastructureRef.current.filter(i => i.type === 'POWER_PLANT' && !i.destroyed);
    const activeJammers = infrastructureRef.current.filter(i => i.type === 'JAMMER' && !i.destroyed);
    const activeRadars = infrastructureRef.current.filter(i => i.type === 'RADAR' && !i.destroyed);

    // 1. Update Drones
    const activeDrones = dronesRef.current.map(drone => {
      if (!drone.active) return drone;

      // JAMMER EFFECT
      let jammed = false;
      if (activeJammers.length > 0) {
          for (const jammer of activeJammers) {
              if (distance(drone.pos, jammer.pos) < JAMMER_RADIUS) {
                  jammed = true;
                  break;
              }
          }
      }
      drone.jammed = jammed;

      let t = drone.target || targetRef.current;
      
      if (drone.returning) {
          let closestSpawn = spawnPointsRef.current[0];
          let minDist = 999999;
          spawnPointsRef.current.forEach(sp => {
              const d = distance(drone.pos, sp);
              if (d < minDist) { minDist = d; closestSpawn = sp; }
          });
          t = closestSpawn;

          if (distance(drone.pos, t) < 20) {
             drone.active = false; 
             onDroneReturned(drone.type);
             spawnFloatingText(drone.pos, "RECOVERED", "#38bdf8");
             return drone;
          }
      }

      const dx = t.x - drone.pos.x;
      const dy = t.y - drone.pos.y;
      const targetAngle = Math.atan2(dy, dx);
      
      const isScout = drone.type === 'SCOUT';
      const isTurbo = drone.type === 'TURBO';
      const isStealth = drone.type === 'STEALTH';
      
      let turnRate = DRONE_ATTACK_TURN;
      let speed = DRONE_ATTACK_SPEED * speedBonus;
      let visionRadius = DRONE_ATTACK_VISION * visionBonus;

      if (isScout) {
          turnRate = DRONE_SCOUT_TURN;
          speed = DRONE_SCOUT_SPEED * speedBonus;
          visionRadius = DRONE_SCOUT_VISION * visionBonus;
      } else if (isTurbo) {
          turnRate = DRONE_TURBO_TURN; 
          speed = DRONE_TURBO_SPEED * speedBonus;
          visionRadius = DRONE_ATTACK_VISION * visionBonus;
      } else if (isStealth) {
          turnRate = DRONE_STEALTH_TURN;
          speed = DRONE_STEALTH_SPEED * speedBonus;
          visionRadius = DRONE_ATTACK_VISION * visionBonus;
      }
      
      // Turbo Jet Trail Effect
      if (isTurbo) {
          if (Math.random() > 0.5) {
              particlesRef.current.push({
                  id: Math.random().toString(),
                  pos: { x: drone.pos.x - Math.cos(drone.angle)*8, y: drone.pos.y - Math.sin(drone.angle)*8 },
                  velocity: { x: -Math.cos(drone.angle), y: -Math.sin(drone.angle) },
                  life: 0.4, decay: 0.05, color: '#a855f7', size: 3, type: 'SPARK'
              });
          }
      }
      
      // Stealth Trail (Subtle)
      if (isStealth) {
          if (Math.random() > 0.8) {
               particlesRef.current.push({
                  id: Math.random().toString(),
                  pos: { x: drone.pos.x, y: drone.pos.y },
                  velocity: { x: 0, y: 0 },
                  life: 0.3, decay: 0.05, color: '#6366f1', size: 2, type: 'SMOKE'
              });
          }
      }

      // REVEAL FOG Logic
      if (fogEnabled) {
          let effectiveVision = gameMode === GameMode.NIGHT_OPS ? (isScout || isStealth ? visionRadius : visionRadius * 0.4) : visionRadius;

          // Reveal Defenses
          defensesRef.current.forEach(def => {
              if (!def.revealed && distance(drone.pos, def.pos) < effectiveVision) {
                  def.revealed = true;
                  setDefenses(prev => prev.map(d => d.id === def.id ? {...d, revealed: true} : d));
                  onLog(`Intel: ${def.type} position revealed!`, 'warning');
                  spawnFloatingText(def.pos, "DETECTED", "#f59e0b");
              }
          });

          // Reveal Infrastructure
          if (gameMode === GameMode.REALISTIC || gameMode === GameMode.NIGHT_OPS) {
              infrastructureRef.current.forEach(inf => {
                  if (!inf.revealed && !inf.destroyed && distance(drone.pos, inf.pos) < effectiveVision) {
                      inf.revealed = true;
                      setInfrastructure(prev => prev.map(i => i.id === inf.id ? {...i, revealed: true} : i));
                      onLog(`Intel: ${inf.type} identified!`, 'warning');
                      spawnFloatingText(inf.pos, "TARGET ID", "#10b981");
                  }
              });
          }
      }

      let angleDiff = targetAngle - drone.angle;
      while (angleDiff <= -Math.PI) angleDiff += Math.PI * 2;
      while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
      
      // Jamming jitter
      if (jammed) {
          angleDiff += (Math.random() - 0.5) * 0.5;
          if (Math.random() > 0.8) {
             spawnFloatingText(drone.pos, "JAMMED", "#dc2626");
          }
      }

      if (Math.abs(angleDiff) < turnRate) {
        drone.angle = targetAngle;
      } else {
        drone.angle += Math.sign(angleDiff) * turnRate;
      }

      drone.velocity.x = Math.cos(drone.angle) * speed;
      drone.velocity.y = Math.sin(drone.angle) * speed;

      drone.pos.x += drone.velocity.x;
      drone.pos.y += drone.velocity.y;

      // Add trail point
      const trailProb = qualitySettings.particles === 'HIGH' ? 0.8 : 0.95;
      if (!isStealth && (Math.random() > trailProb || drone.trail.length === 0)) {
         drone.trail.push({ ...drone.pos });
         if (drone.trail.length > 25) drone.trail.shift();
      }

      // --- COLLISIONS (Attack/Turbo/Stealth Drone vs Objects) ---
      if (!isScout && !drone.returning && gameMode !== GameMode.BASE_DEFENSE) {
          // 1. Collision with Target (Generic Mode)
          if (gameMode !== GameMode.REALISTIC) {
            if (distance(drone.pos, targetRef.current) < 20) {
                spawnExplosion(targetRef.current, '#f43f5e', 120, false);
                spawnFloatingText(targetRef.current, "TARGET DESTROYED", "#f43f5e");
                drone.active = false;
                
                if (gameMode === GameMode.SURVIVAL) {
                    onLog("TARGET DESTROYED! Reinforcements inbound...", 'success');
                    if (onTargetDestroyed) onTargetDestroyed();
                    
                    // Move Target
                    const newTarget = {
                        x: 200 + Math.random() * (GAME_WIDTH - 400),
                        y: 100 + Math.random() * (GAME_HEIGHT - 200)
                    };
                    setTarget(newTarget);

                    // Add Defense
                    const types: Defense['type'][] = ['AA_GUN', 'FLAK', 'SAM'];
                    const newDef: Defense = {
                        id: Math.random().toString(),
                        pos: {
                            x: 100 + Math.random() * (GAME_WIDTH - 200),
                            y: 100 + Math.random() * (GAME_HEIGHT - 200)
                        },
                        range: 0, cooldown: 0, lastFired: 0, angle: 0, revealed: false,
                        type: types[Math.floor(Math.random() * types.length)],
                        health: AA_GUN_HEALTH, maxHealth: AA_GUN_HEALTH
                    };
                    if (newDef.type === 'SAM') { newDef.health = SAM_HEALTH; newDef.maxHealth = SAM_HEALTH; }
                    if (newDef.type === 'FLAK') { newDef.health = FLAK_HEALTH; newDef.maxHealth = FLAK_HEALTH; }
                    
                    setDefenses(prev => [...prev, newDef]);
                } else {
                    if (onTargetDestroyed) onTargetDestroyed();
                }
            }
          }

          // 2. Collision with Defenses (SEAD - Suppression of Enemy Air Defenses)
          defensesRef.current.forEach(def => {
              if (distance(drone.pos, def.pos) < 20) {
                  drone.active = false;
                  spawnExplosion(def.pos, '#fbbf24', 40, false);
                  const dmg = DRONE_DAMAGE * (isTurbo ? 1.5 : 1.0); // Turbo does more kinetic damage
                  def.health -= dmg;
                  spawnFloatingText(def.pos, `-${Math.floor(dmg)} HP`, "#ef4444");

                  if (def.health <= 0) {
                       onLog(`${def.type} neutralized!`, 'success');
                       spawnFloatingText(def.pos, "DESTROYED", "#ef4444");
                       setDefenses(prev => prev.filter(d => d.id !== def.id));
                       spawnExplosion(def.pos, '#ef4444', 80, false);
                       if(onDefenseDestroyed) onDefenseDestroyed(def.type);
                  } else {
                       setDefenses(prev => prev.map(d => d.id === def.id ? {...d, health: def.health} : d));
                       onLog(`${def.type} damaged!`, 'info');
                  }
              }
          });

          // 3. Collision with Infrastructure (Realistic Mode)
          if (gameMode === GameMode.REALISTIC || gameMode === GameMode.SANDBOX || gameMode === GameMode.NIGHT_OPS) {
              infrastructureRef.current.forEach(inf => {
                  if (!inf.destroyed && distance(drone.pos, inf.pos) < 25) {
                      drone.active = false;
                      const isFuel = inf.type === 'FUEL_DEPOT';
                      
                      // BIG BOOM for Fuel
                      const explosionRadius = isFuel ? 200 : 60;
                      const damageOthers = isFuel;

                      spawnExplosion(inf.pos, isFuel ? '#f59e0b' : '#fbbf24', explosionRadius, damageOthers);
                      
                      const dmg = DRONE_DAMAGE * (isTurbo ? 1.5 : 1.0);
                      inf.health -= dmg;
                      spawnFloatingText(inf.pos, `-${Math.floor(dmg)} HP`, "#ef4444");

                      if (inf.health <= 0) {
                          inf.destroyed = true;
                          inf.health = 0;
                          inf.destroyedTime = Date.now();
                          onLog(`${inf.type} ELIMINATED!`, 'success');
                          spawnFloatingText(inf.pos, "DEMOLISHED", "#f43f5e");
                          
                          if (isFuel) {
                              spawnExplosion(inf.pos, '#f43f5e', 300, true);
                              addShake(15);
                          } else {
                              spawnExplosion(inf.pos, '#f43f5e', 150, false);
                          }

                          // Command Center Reveal Effect
                          if (inf.type === 'COMMAND_CENTER') {
                              onLog("Enemy C2 Destroyed. Map Revealed.", 'success');
                              setDefenses(prev => prev.map(d => ({...d, revealed: true})));
                              setInfrastructure(prev => prev.map(i => ({...i, revealed: true})));
                          }
                          
                          setInfrastructure(prev => prev.map(i => i.id === inf.id ? {...i, health: 0, destroyed: true, destroyedTime: Date.now()} : i));
                          if (onTargetDestroyed) onTargetDestroyed(); 
                      } else {
                          setInfrastructure(prev => prev.map(i => i.id === inf.id ? {...i, health: inf.health} : i));
                          onLog(`Target Hit: ${inf.type}`, 'info');
                      }
                  }
              });
          }
      } else if (gameMode === GameMode.BASE_DEFENSE && !drone.returning) {
          // In Base Defense, drones attack spawn points (which act as player base)
          spawnPointsRef.current.forEach((sp, idx) => {
              if (distance(drone.pos, sp) < 20) {
                  drone.active = false;
                  spawnExplosion(sp, '#ef4444', 50, false);
                  spawnFloatingText(sp, "BASE HIT!", "#ef4444");
                  if (onTargetDestroyed) onTargetDestroyed(); // Actually "Base Damaged" callback reused
              }
          });
      }

      return drone;
    });

    // 2. Update Defenses
    const updatedDefenses = defensesRef.current.map(def => {
      // Clear previous lock status at start of frame
      def.targetId = null;

      if (def.cooldown > 0) {
        return { ...def, cooldown: def.cooldown - 1 };
      }
      
      // CHECK POWER & EMP
      let hasPower = true;
      if (activeSupport.emp) hasPower = false; // EMP DISABLES ALL
      else if (gameMode !== GameMode.SANDBOX && gameMode !== GameMode.BASE_DEFENSE) {
          if (hasPowerPlants) {
            const nearestPower = activePowerPlants.find(p => distance(p.pos, def.pos) < POWER_GRID_RADIUS);
            if (!nearestPower) hasPower = false;
          }
      }
      def.powered = hasPower;

      if (!hasPower) return def; // Cannot fire if no power

      // Smoke effect if damaged
      if (def.health < def.maxHealth && Math.random() > 0.9) {
          particlesRef.current.push({
            id: Math.random().toString(),
            pos: { x: def.pos.x + (Math.random()-0.5)*10, y: def.pos.y - 10 },
            velocity: { x: (Math.random()-0.5), y: -1 },
            life: 0.8, decay: 0.02, color: '#52525b', size: 4, type: 'SMOKE'
        });
      }

      let activeRange = AA_GUN_RANGE;
      if (def.type === 'SAM') activeRange = SAM_RANGE;
      if (def.type === 'FLAK') activeRange = FLAK_RANGE;
      
      // STEALTH LOGIC: Reduce range if drone is STEALTH
      const targetDrone = activeDrones.find(d => {
          if (!d.active || d.returning) return false; // Don't shoot returning drones (mercy/gameplay choice)
          // In Base Defense, AI drones are just normal targets
          const effectiveRange = (d.type === 'STEALTH' && gameMode !== GameMode.BASE_DEFENSE) ? activeRange * DRONE_STEALTH_VISIBILITY : activeRange;
          return distance(d.pos, def.pos) <= effectiveRange;
      });
      
      if (targetDrone) {
        // Set visual lock
        def.targetId = targetDrone.id;

        const angle = Math.atan2(targetDrone.pos.y - def.pos.y, targetDrone.pos.x - def.pos.x);
        
        let projectileType: Projectile['type'] = 'BULLET';
        let speed = AA_GUN_PROJECTILE_SPEED;
        let cooldownTime = AA_GUN_COOLDOWN;
        let fireAngle = angle;
        let targetPosForShell = undefined;

        if (def.type === 'SAM') {
          projectileType = 'MISSILE';
          speed = SAM_PROJECTILE_SPEED;
          cooldownTime = SAM_COOLDOWN;
        } else if (def.type === 'FLAK') {
          projectileType = 'FLAK_SHELL';
          speed = FLAK_PROJECTILE_SPEED;
          cooldownTime = FLAK_COOLDOWN;
          const dist = distance(def.pos, targetDrone.pos);
          const timeToImpact = dist / speed;
          targetPosForShell = {
            x: targetDrone.pos.x + targetDrone.velocity.x * timeToImpact,
            y: targetDrone.pos.y + targetDrone.velocity.y * timeToImpact
          };
        } else {
            fireAngle = angle + (Math.random() - 0.5) * AA_GUN_ACCURACY;
        }

        projectilesRef.current.push({
          id: Math.random().toString(),
          type: projectileType,
          pos: { ...def.pos },
          velocity: { 
            x: Math.cos(fireAngle) * speed, 
            y: Math.sin(fireAngle) * speed 
          },
          speed: speed,
          targetId: targetDrone.id,
          targetPos: targetPosForShell,
          active: true,
          birthTime: Date.now(),
          trail: []
        });

        if (qualitySettings.particles === 'HIGH' || Math.random() > 0.5) {
            particlesRef.current.push({
                id: Math.random().toString(),
                pos: { x: def.pos.x + Math.cos(angle)*20, y: def.pos.y + Math.sin(angle)*20 },
                velocity: { x: Math.cos(angle), y: Math.sin(angle) },
                life: 0.5, decay: 0.1, color: '#fde047', size: 3, type: 'SPARK'
            });
        }

        return { ...def, cooldown: cooldownTime, lastFired: Date.now(), angle };
      }
      return def;
    });

    // 3. Update Projectiles
    projectilesRef.current = projectilesRef.current.map(proj => {
      if (!proj.active) return proj;
      
      if (proj.type === 'MISSILE') {
        const targetDrone = activeDrones.find(d => d.id === proj.targetId && d.active);
        if (targetDrone) {
           const dx = targetDrone.pos.x - proj.pos.x;
           const dy = targetDrone.pos.y - proj.pos.y;
           const angle = Math.atan2(dy, dx);
           proj.speed += SAM_PROJECTILE_ACCEL;
           proj.velocity.x = Math.cos(angle) * proj.speed;
           proj.velocity.y = Math.sin(angle) * proj.speed;
        }
        if (qualitySettings.particles === 'HIGH' && Math.random() > 0.2) {
            particlesRef.current.push({
                id: Math.random().toString(),
                pos: { ...proj.pos },
                velocity: { x: -proj.velocity.x*0.1, y: -proj.velocity.y*0.1 },
                life: 0.8, decay: 0.03, color: '#94a3b8', size: 2, type: 'SMOKE'
            });
        }
      } 
      
      proj.pos.x += proj.velocity.x;
      proj.pos.y += proj.velocity.y;

      if (proj.pos.x < -50 || proj.pos.x > GAME_WIDTH + 50 || proj.pos.y < -50 || proj.pos.y > GAME_HEIGHT + 50) {
        proj.active = false;
      }

      // Hit Logic
      if (proj.type === 'FLAK_SHELL' && proj.targetPos) {
        if (distance(proj.pos, proj.targetPos) < proj.speed * 1.5) {
            proj.active = false;
            spawnExplosion(proj.pos, '#ef4444', FLAK_EXPLOSION_RADIUS, true);
        }
      } else {
          const hitDist = proj.type === 'MISSILE' ? 15 : 8;
          const hitTarget = activeDrones.find(d => d.active && distance(proj.pos, d.pos) < hitDist);
          
          if (hitTarget) {
            proj.active = false;
            
            // SCOUT / TURBO / TECH EVASION CHANCE
            let dodgeChance = 0;
            if (hitTarget.type === 'SCOUT') dodgeChance = 0.3;
            else if (hitTarget.type === 'TURBO') dodgeChance = 0.15;
            else if (hitTarget.type === 'STEALTH') dodgeChance = 0.2;
            
            // Upgrade Bonus
            if (upgrades.has('tech_armor')) dodgeChance += 0.25;

            if (Math.random() < dodgeChance) {
                spawnFloatingText(hitTarget.pos, "EVADED", "#38bdf8");
                onLog(`${hitTarget.type} evaded incoming fire!`, 'info');
            } else {
                hitTarget.active = false;
                spawnExplosion(hitTarget.pos, '#fbbf24', proj.type === 'MISSILE' ? 50 : 20);
                spawnFloatingText(hitTarget.pos, "DESTROYED", "#fbbf24");
                onLog(`${hitTarget.type} destroyed!`, 'danger');
                if(gameMode === GameMode.BASE_DEFENSE && onDefenseDestroyed) {
                    // In Base Defense, killing a drone is good!
                    onDefenseDestroyed("DRONE_KILL");
                }
            }
          }
      }

      return proj;
    }).filter(p => p.active);

    // 4. Update Particles & Infrastructure Smoke & Logic
    particlesRef.current = particlesRef.current.map(p => {
        p.pos.x += p.velocity.x;
        p.pos.y += p.velocity.y;
        p.life -= p.decay;
        if (p.type === 'SMOKE') {
             p.velocity.x *= 0.98;
             p.velocity.y *= 0.98;
        } else {
            p.velocity.x *= 0.95;
            p.velocity.y *= 0.95;
        }
        return p;
    }).filter(p => p.life > 0);
    
    // Infrastructure damage effects & functionality
    infrastructureRef.current.forEach(inf => {
        // 1. Damage Smoke
        if (!inf.destroyed && inf.health < inf.maxHealth) {
             if (Math.random() > 0.85) {
                 particlesRef.current.push({
                    id: Math.random().toString(),
                    pos: { x: inf.pos.x + (Math.random()-0.5)*20, y: inf.pos.y - (Math.random() * 20) },
                    velocity: { x: (Math.random()-0.5), y: -1.5 },
                    life: 1.2, decay: 0.015, color: '#4b5563', size: 6, type: 'SMOKE'
                });
             }
        }
        
        // 2. Destroyed Logic (Smoke for 20s, Disappear after 40s)
        if (inf.destroyed && inf.destroyedTime) {
            const timeSinceDestruction = now - inf.destroyedTime;

            // Smoke for 20 seconds
            if (timeSinceDestruction < 20000) {
                if (Math.random() > 0.6) { // Heavy smoke
                    particlesRef.current.push({
                        id: Math.random().toString(),
                        pos: { x: inf.pos.x + (Math.random()-0.5)*25, y: inf.pos.y },
                        velocity: { x: (Math.random()-0.5)*0.5, y: -0.5 - Math.random() },
                        life: 1.0, decay: 0.008, color: '#18181b', size: 8 + Math.random() * 5, type: 'SMOKE'
                    });
                }
            }
            
            // Remove after 40 seconds
            if (timeSinceDestruction > 40000) {
                onInfrastructureCleanup(inf.id);
            }
        }
        
        // Factory Logic: Generate Cash visuals
        if (inf.type === 'WAREHOUSE' && !inf.destroyed && Math.random() > 0.99) {
             spawnFloatingText(inf.pos, "+$$$", "#10b981");
        }
    });

    floatingTextsRef.current = floatingTextsRef.current.map(ft => {
        ft.pos.x += ft.velocity.x;
        ft.pos.y += ft.velocity.y;
        ft.life -= 0.015;
        return ft;
    }).filter(ft => ft.life > 0);

    // 5. Update Explosions
    explosionsRef.current = explosionsRef.current.map(exp => {
      exp.radius += 1.5;
      exp.alpha -= 0.05;

      if (exp.damage && exp.alpha > 0.5) {
         // Damage Drones
         activeDrones.forEach(d => {
             if (d.active && distance(d.pos, exp.pos) < exp.radius) {
                 const dodgeChance = d.type === 'SCOUT' ? 0.3 : 0; 
                 if (Math.random() < dodgeChance) {
                     if (!floatingTextsRef.current.some(ft => ft.pos.x === d.pos.x && ft.text === "EVADED")) {
                         spawnFloatingText(d.pos, "EVADED", "#38bdf8");
                     }
                 } else {
                    d.active = false;
                    spawnExplosion(d.pos, '#fbbf24', 30, false);
                    onLog(`Drone caught in blast!`, 'danger');
                    if(gameMode === GameMode.BASE_DEFENSE && onDefenseDestroyed) {
                        onDefenseDestroyed("DRONE_KILL");
                    }
                 }
             }
         });

         // Damage Infrastructure/Defense (Collateral)
         if (exp.radius > 100) { // Only big explosions cause collateral
            infrastructureRef.current.forEach(inf => {
                if (!inf.destroyed && distance(inf.pos, exp.pos) < exp.radius) {
                    inf.health -= 5; // Chain reaction trickle damage
                    if (inf.health <= 0) {
                        inf.destroyed = true;
                        inf.destroyedTime = Date.now();
                        spawnExplosion(inf.pos, '#f43f5e', 100, true);
                    }
                }
            });
            defensesRef.current.forEach(def => {
                 if (distance(def.pos, exp.pos) < exp.radius) {
                     def.health -= 2;
                     if (def.health <= 0) {
                         setDefenses(prev => prev.filter(d => d.id !== def.id));
                         spawnExplosion(def.pos, '#ef4444', 80, false);
                     }
                 }
            });
         }
      }
      return exp;
    }).filter(exp => exp.alpha > 0);

    shockwavesRef.current = shockwavesRef.current.map(sw => {
        sw.radius += 3;
        sw.alpha -= 0.02;
        return sw;
    }).filter(sw => sw.alpha > 0);

    dronesRef.current = activeDrones;
    defensesRef.current = updatedDefenses;
  };

  // --- DRAWING ---
  const draw = (ctx: CanvasRenderingContext2D) => {
    ctx.save();
    if (shakeRef.current > 0 && qualitySettings.shake) {
        const dx = (Math.random() - 0.5) * shakeRef.current * 2;
        const dy = (Math.random() - 0.5) * shakeRef.current * 2;
        ctx.translate(dx, dy);
    }

    // Background: Clean Tactical Dark Blue
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(-20, -20, GAME_WIDTH+40, GAME_HEIGHT+40); 

    // Better Tactical Grid
    ctx.lineWidth = 1;
    ctx.strokeStyle = '#1e293b';
    
    // Subgrid
    ctx.beginPath();
    for (let x = 0; x <= GAME_WIDTH; x += 20) { ctx.moveTo(x, 0); ctx.lineTo(x, GAME_HEIGHT); }
    for (let y = 0; y <= GAME_HEIGHT; y += 20) { ctx.moveTo(0, y); ctx.lineTo(GAME_WIDTH, y); }
    ctx.strokeStyle = 'rgba(30, 41, 59, 0.3)';
    ctx.stroke();

    // Major Grid
    ctx.beginPath();
    for (let x = 0; x <= GAME_WIDTH; x += 100) { ctx.moveTo(x, 0); ctx.lineTo(x, GAME_HEIGHT); }
    for (let y = 0; y <= GAME_HEIGHT; y += 100) { ctx.moveTo(0, y); ctx.lineTo(GAME_WIDTH, y); }
    ctx.strokeStyle = '#334155';
    ctx.stroke();

    // --- TARGET LOCK LINES (New Feature) ---
    // This draws a line from Defense to Drone if it's targeting it
    defensesRef.current.forEach(def => {
       if (def.targetId) {
           const drone = dronesRef.current.find(d => d.id === def.targetId);
           if (drone && drone.active) {
               ctx.save();
               ctx.beginPath();
               ctx.moveTo(def.pos.x, def.pos.y);
               ctx.lineTo(drone.pos.x, drone.pos.y);
               ctx.setLineDash([5, 5]);
               ctx.lineWidth = 1;
               // Pulsing red
               const alpha = 0.5 + Math.sin(Date.now() / 100) * 0.4;
               ctx.strokeStyle = `rgba(239, 68, 68, ${alpha})`;
               ctx.stroke();
               ctx.restore();
           }
       }
    });

    // --- POWER LINES (Visual) ---
    const powerPlants = infrastructureRef.current.filter(i => i.type === 'POWER_PLANT' && !i.destroyed);
    if (powerPlants.length > 0) {
        defensesRef.current.forEach(def => {
             // In Base Defense, you (player) see all lines. In attack, depends on fog
             const visible = !fogEnabled || def.revealed || activeSupport.scan || gameMode === GameMode.BASE_DEFENSE;
             if (!visible) return;
             
             let connected = false;
             powerPlants.forEach(pp => {
                 const ppVisible = !fogEnabled || pp.revealed || activeSupport.scan || gameMode === GameMode.BASE_DEFENSE;
                 if (!ppVisible) return;

                 if (distance(def.pos, pp.pos) < POWER_GRID_RADIUS) {
                     connected = true;
                     ctx.strokeStyle = '#eab308';
                     ctx.lineWidth = 1;
                     ctx.globalAlpha = 0.2;
                     ctx.beginPath(); 
                     ctx.moveTo(pp.pos.x, pp.pos.y); 
                     ctx.lineTo(def.pos.x, def.pos.y); 
                     ctx.stroke();
                 }
             });
        });
        ctx.globalAlpha = 1;
    }
    
    // --- RADAR RINGS ---
    const radars = infrastructureRef.current.filter(i => i.type === 'RADAR' && !i.destroyed);
    radars.forEach(r => {
        if (fogEnabled && !r.revealed && gameMode !== GameMode.SANDBOX && !activeSupport.scan && gameMode !== GameMode.BASE_DEFENSE) return;
        
        // Draw radar sweep range
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.1)';
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(r.pos.x, r.pos.y, RADAR_REVEAL_RADIUS, 0, Math.PI*2); ctx.stroke();
        
        // Scanning effect
        const angle = (Date.now() / 1000) % (Math.PI * 2);
        ctx.save();
        ctx.translate(r.pos.x, r.pos.y);
        ctx.rotate(angle);
        ctx.fillStyle = 'rgba(56, 189, 248, 0.1)';
        ctx.beginPath();
        ctx.moveTo(0,0);
        ctx.arc(0,0, RADAR_REVEAL_RADIUS, -0.2, 0.2);
        ctx.fill();
        ctx.restore();
    });

    // --- JAMMER RINGS ---
    const jammers = infrastructureRef.current.filter(i => i.type === 'JAMMER' && !i.destroyed);
    jammers.forEach(j => {
        if (fogEnabled && !j.revealed && gameMode !== GameMode.SANDBOX && !activeSupport.scan && gameMode !== GameMode.BASE_DEFENSE) return;
        ctx.strokeStyle = 'rgba(220, 38, 38, 0.3)';
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 10]);
        ctx.beginPath(); ctx.arc(j.pos.x, j.pos.y, JAMMER_RADIUS, 0, Math.PI*2); ctx.stroke();
        ctx.setLineDash([]);
    });

    // --- DEFENSES ---
    defensesRef.current.forEach(def => {
      // In Base Defense, player owns defenses, so always show them
      const visible = gameMode === GameMode.BASE_DEFENSE ? true : (!fogEnabled || def.revealed || activeSupport.scan);
      if (!visible) return; 

      let range = AA_GUN_RANGE;
      let color = '245, 158, 11';
      if (def.type === 'SAM') { range = SAM_RANGE; color = '239, 68, 68'; }
      if (def.type === 'FLAK') { range = FLAK_RANGE; color = '249, 115, 22'; }
      
      const powered = def.powered !== false; // Default true

      if (powered && qualitySettings.particles === 'HIGH') {
          ctx.strokeStyle = `rgba(${color}, 0.1)`;
          ctx.fillStyle = `rgba(${color}, 0.03)`;
          ctx.beginPath(); ctx.arc(def.pos.x, def.pos.y, range, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      }

      ctx.save();
      ctx.translate(def.pos.x, def.pos.y);
      
      // Shadows
      if (qualitySettings.shadows) {
          ctx.shadowColor = 'rgba(0,0,0,0.5)';
          ctx.shadowBlur = 5;
          ctx.shadowOffsetY = 5;
      }

      // Health Bar for Defenses
      if (def.health < def.maxHealth) {
          const pct = def.health / def.maxHealth;
          ctx.fillStyle = 'red';
          ctx.fillRect(-10, -20, 20, 4);
          ctx.fillStyle = '#10b981';
          ctx.fillRect(-10, -20, 20 * pct, 4);
      }

      // Offline Indicator (EMP or No Power)
      if (!powered) {
          ctx.fillStyle = '#1e293b'; // Dark base
          ctx.beginPath(); ctx.arc(0,0, 12, 0, Math.PI*2); ctx.fill();
          ctx.rotate(def.angle);
          ctx.fillStyle = '#334155'; // Dark gun
          if (def.type === 'AA_GUN') ctx.fillRect(-8, -8, 16, 16);
          else ctx.fillRect(-10, -10, 20, 20);
          
          // EMP Sparks or No Power Icon
          if (activeSupport.emp) {
             ctx.strokeStyle = '#38bdf8';
             ctx.lineWidth = 2;
             const t = Date.now() / 100;
             ctx.beginPath(); 
             ctx.moveTo(-8 + Math.sin(t)*2, -8); 
             ctx.lineTo(8 + Math.sin(t+1)*2, 8); 
             ctx.stroke();
          } else {
             // No Power Icon (Yellow Bolt Struck through)
             ctx.fillStyle = '#000';
             ctx.fillRect(-5, -8, 10, 16);
             ctx.strokeStyle = '#eab308';
             ctx.lineWidth = 2;
             ctx.beginPath(); ctx.moveTo(-5, -5); ctx.lineTo(5, 5); ctx.moveTo(5, -5); ctx.lineTo(-5, 5); ctx.stroke();
          }
      } else {
          // Dynamic Lighting Gradient
          let baseColor = '#334155';
          if (qualitySettings.lighting === 'DYNAMIC') {
              const grad = ctx.createRadialGradient(0,0, 2, 0,0, 12);
              grad.addColorStop(0, '#475569');
              grad.addColorStop(1, '#1e293b');
              ctx.fillStyle = grad;
          } else {
              ctx.fillStyle = baseColor;
          }
          
          ctx.beginPath(); ctx.arc(0,0, 12, 0, Math.PI*2); ctx.fill();

          if (def.type === 'AA_GUN') {
            ctx.rotate(def.angle);
            ctx.fillStyle = '#b45309'; 
            ctx.fillRect(-8, -8, 16, 16);
            ctx.fillStyle = '#f59e0b';
            ctx.fillRect(0, -3, 20, 2); ctx.fillRect(0, 1, 20, 2);
          } else if (def.type === 'FLAK') {
            ctx.rotate(def.angle);
            ctx.fillStyle = '#7c2d12';
            ctx.fillRect(-10, -10, 20, 20);
            ctx.fillStyle = '#fdba74';
            ctx.fillRect(0, -4, 24, 8); 
          } else {
            ctx.fillStyle = '#b91c1c';
            ctx.fillRect(-10, -10, 20, 20);
            ctx.rotate(def.angle);
            ctx.fillStyle = '#fca5a5';
            ctx.fillRect(-8, -6, 6, 12); ctx.fillRect(2, -6, 6, 12);
          }
      }
      ctx.restore();
    });

    // --- INFRASTRUCTURE ---
    infrastructureRef.current.forEach(inf => {
        const visible = gameMode === GameMode.BASE_DEFENSE ? true : (gameMode === GameMode.SANDBOX || inf.revealed || inf.destroyed || activeSupport.scan);
        if (!visible) return;

        ctx.save();
        ctx.translate(inf.pos.x, inf.pos.y);
        
        // Shadows
        if (qualitySettings.shadows && !inf.destroyed) {
            ctx.shadowColor = 'rgba(0,0,0,0.6)';
            ctx.shadowBlur = 10;
            ctx.shadowOffsetY = 8;
        }
        
        const color = inf.destroyed ? '#334155' : '#e2e8f0';
        
        // Draw Building Base
        ctx.fillStyle = inf.destroyed ? '#0f172a' : '#1e293b';
        if (qualitySettings.lighting === 'DYNAMIC' && !inf.destroyed) {
             const grad = ctx.createLinearGradient(-20, -20, 20, 20);
             grad.addColorStop(0, '#334155');
             grad.addColorStop(1, '#0f172a');
             ctx.fillStyle = grad;
        }
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        
        if (inf.type === 'POWER_PLANT') {
            ctx.fillRect(-15, -15, 30, 30);
            ctx.strokeRect(-15, -15, 30, 30);
            if (!inf.destroyed) {
                ctx.fillStyle = '#facc15'; // Yellow Zap
                if (qualitySettings.bloom) ctx.shadowColor = '#facc15'; ctx.shadowBlur = 10;
                ctx.font = '20px monospace';
                ctx.fillText('⚡', -8, 6);
                ctx.shadowBlur = 0;
            }
        } else if (inf.type === 'COMMAND_CENTER') {
            ctx.beginPath(); ctx.moveTo(0, -20); ctx.lineTo(20, 15); ctx.lineTo(-20, 15); ctx.closePath();
            ctx.fill(); ctx.stroke();
            if (!inf.destroyed) {
                ctx.fillStyle = '#f43f5e';
                ctx.font = '16px monospace';
                ctx.fillText('★', -5, 6);
            }
        } else if (inf.type === 'RADAR') {
            ctx.beginPath(); ctx.arc(0, 0, 15, 0, Math.PI, true); ctx.fill(); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(0, -15); ctx.stroke();
            // Rotating dish
            if (!inf.destroyed) {
                ctx.rotate(Date.now() / 500);
                ctx.strokeStyle = '#38bdf8';
                ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(0, -12); ctx.stroke();
            }
        } else if (inf.type === 'JAMMER') {
             ctx.beginPath(); ctx.arc(0,0, 12, 0, Math.PI*2); ctx.fill(); ctx.stroke();
             // Pulse rings
             if (!inf.destroyed) {
                 const pulse = (Date.now() % 1000) / 200;
                 ctx.strokeStyle = '#ef4444';
                 ctx.beginPath(); ctx.moveTo(-10, -10); ctx.lineTo(10, 10); ctx.moveTo(10, -10); ctx.lineTo(-10, 10); ctx.stroke();
             }
        } else if (inf.type === 'FUEL_DEPOT') {
             ctx.beginPath(); ctx.arc(0, 0, 15, 0, Math.PI*2); ctx.fill(); ctx.stroke();
             if(!inf.destroyed) {
                 ctx.fillStyle = '#f97316';
                 ctx.font = 'bold 12px monospace';
                 ctx.fillText("OIL", -10, 4);
             }
        } else {
            // Warehouse
            ctx.fillRect(-20, -10, 40, 20);
            ctx.strokeRect(-20, -10, 40, 20);
            ctx.beginPath(); ctx.moveTo(-20, -10); ctx.lineTo(0, -20); ctx.lineTo(20, -10); ctx.stroke();
        }

        // Health Bar
        if (!inf.destroyed && inf.health < inf.maxHealth) {
            const pct = Math.max(0, inf.health / inf.maxHealth);
            ctx.fillStyle = 'red';
            ctx.fillRect(-15, -30, 30, 4);
            ctx.fillStyle = '#facc15';
            ctx.fillRect(-15, -30, 30 * pct, 4);
        }
        
        if (inf.destroyed) {
             ctx.fillStyle = '#ef4444';
             ctx.font = 'bold 10px JetBrains Mono';
             ctx.fillText("DESTROYED", -25, 25);
        } else if (visible) {
             ctx.fillStyle = '#e2e8f0';
             ctx.font = '10px JetBrains Mono';
             ctx.fillText(inf.type.replace('_', ' '), -25, 35);
        }

        ctx.restore();
    });

    // --- TARGET (Classic Mode) ---
    if (gameMode !== GameMode.REALISTIC && gameMode !== GameMode.BASE_DEFENSE) {
        const t = targetRef.current;
        if (!fogEnabled || gameMode === GameMode.SANDBOX || activeSupport.scan) {
            ctx.shadowBlur = 20; ctx.shadowColor = '#f43f5e'; ctx.strokeStyle = '#f43f5e'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(t.x, t.y, 12, 0, Math.PI * 2); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(t.x - 8, t.y - 8); ctx.lineTo(t.x + 8, t.y + 8); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(t.x + 8, t.y - 8); ctx.lineTo(t.x - 8, t.y + 8); ctx.stroke();
            ctx.shadowBlur = 0;
            
            if (qualitySettings.particles === 'HIGH') {
                const pulse = (Date.now() % 1000) / 1000;
                ctx.strokeStyle = `rgba(244, 63, 94, ${1-pulse})`;
                ctx.beginPath(); ctx.arc(t.x, t.y, 12 + pulse * 20, 0, Math.PI*2); ctx.stroke();
            }
        } else {
            ctx.fillStyle = 'rgba(244, 63, 94, 0.3)';
            ctx.beginPath(); ctx.arc(t.x, t.y, 5, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = '#f43f5e';
            ctx.font = '10px JetBrains Mono';
            ctx.fillText("TARGET ZONE", t.x - 30, t.y + 20);
        }
    }

    // Spawn Points / Bases
    spawnPointsRef.current.forEach((sp, index) => {
      ctx.fillStyle = gameMode === GameMode.BASE_DEFENSE ? '#ef4444' : '#3b82f6';
      ctx.beginPath(); ctx.arc(sp.x, sp.y, 6, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = gameMode === GameMode.BASE_DEFENSE ? '#f87171' : '#60a5fa';
      ctx.beginPath(); ctx.arc(sp.x, sp.y, 10, 0, Math.PI * 2); ctx.stroke();
      ctx.font = 'bold 14px JetBrains Mono';
      ctx.fillStyle = gameMode === GameMode.BASE_DEFENSE ? '#f87171' : '#60a5fa';
      ctx.fillText(`BASE ${index + 1}`, sp.x - 25, sp.y + 25);
    });

    // Drones
    dronesRef.current.forEach(drone => {
      if (!drone.active) return;
      
      const isScout = drone.type === 'SCOUT';
      const isTurbo = drone.type === 'TURBO';
      const isStealth = drone.type === 'STEALTH';
      
      let color = '#10b981';
      if (isScout) color = '#38bdf8';
      else if (isTurbo) color = '#a855f7'; 
      else if (isStealth) color = '#6366f1'; // Indigo/Ghost
      
      // In Base Defense, drones are enemies (red)
      if (gameMode === GameMode.BASE_DEFENSE) {
          color = '#ef4444';
      }

      if ((fogEnabled || activeSupport.scan) && gameMode !== GameMode.BASE_DEFENSE) {
          const vRad = isScout ? DRONE_SCOUT_VISION : DRONE_ATTACK_VISION;
          // If scan is active, don't draw vision bubbles as much or draw them differently
          if (!activeSupport.scan) {
            const grad = ctx.createRadialGradient(drone.pos.x, drone.pos.y, 10, drone.pos.x, drone.pos.y, vRad);
            grad.addColorStop(0, `rgba(${isScout ? '56, 189, 248' : (isStealth ? '99, 102, 241' : '16, 185, 129')}, 0.1)`);
            grad.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.fillStyle = grad;
            ctx.beginPath(); ctx.arc(drone.pos.x, drone.pos.y, vRad, 0, Math.PI*2); ctx.fill();
          }
      }

      // Better Trails: Smooth lines instead of points
      ctx.strokeStyle = `rgba(255,255,255, 0.3)`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      if (drone.trail.length > 1) {
        ctx.moveTo(drone.trail[0].x, drone.trail[0].y);
        // Quadratic bezier curve for smoothness
        for(let i=1; i<drone.trail.length - 1; i++) {
             const xc = (drone.trail[i].x + drone.trail[i+1].x) / 2;
             const yc = (drone.trail[i].y + drone.trail[i+1].y) / 2;
             ctx.quadraticCurveTo(drone.trail[i].x, drone.trail[i].y, xc, yc);
        }
        ctx.stroke();
      }

      ctx.save();
      ctx.translate(drone.pos.x, drone.pos.y);
      
      // Shadows
      if (qualitySettings.shadows) {
          ctx.shadowColor = 'black';
          ctx.shadowBlur = 5;
          ctx.shadowOffsetY = 10; // Flying high
      }

      if (drone.jammed) {
          // Jitter effect
          ctx.translate((Math.random()-0.5)*2, (Math.random()-0.5)*2);
      }
      ctx.rotate(drone.angle);
      ctx.fillStyle = color;
      // Bloom effect
      if (qualitySettings.bloom) {
          ctx.shadowColor = color;
          ctx.shadowBlur = 15;
          ctx.shadowOffsetY = 0;
      }
      
      ctx.beginPath();
      if (isScout) {
          ctx.moveTo(8, 0); ctx.lineTo(-6, -4); ctx.lineTo(-6, 4);
      } else if (isTurbo) {
          // Turbo Shape (Sharper, longer)
          ctx.moveTo(14, 0); ctx.lineTo(-8, -5); ctx.lineTo(-4, 0); ctx.lineTo(-8, 5);
      } else if (isStealth) {
          // Stealth (Triangle, dark center)
          ctx.moveTo(10, 0); ctx.lineTo(-8, -8); ctx.lineTo(-4, 0); ctx.lineTo(-8, 8);
          ctx.fillStyle = '#312e81'; // Dark center
          ctx.strokeStyle = '#6366f1';
          ctx.lineWidth = 2;
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
      } else {
          ctx.moveTo(10, 0); ctx.lineTo(-6, -8); ctx.lineTo(-2, 0); ctx.lineTo(-6, 8);
      }
      if (!isStealth) {
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = gameMode === GameMode.BASE_DEFENSE ? '#000' : '#fbbf24';
        ctx.beginPath(); ctx.arc(-6, 0, 1.5, 0, Math.PI*2); ctx.fill();
      }
      
      ctx.restore();

      // RTB Status
      if (drone.returning) {
          ctx.fillStyle = '#38bdf8';
          ctx.font = 'bold 10px JetBrains Mono';
          ctx.textAlign = 'center';
          ctx.fillText("RTB", drone.pos.x, drone.pos.y - 15);
          
          // Blinking circle
          const blink = Math.sin(Date.now()/100) > 0;
          if (blink) {
             ctx.strokeStyle = '#38bdf8';
             ctx.lineWidth = 1;
             ctx.beginPath(); ctx.arc(drone.pos.x, drone.pos.y, 8, 0, Math.PI*2); ctx.stroke();
          }
      }
    });

    // Projectiles
    projectilesRef.current.forEach(proj => {
      if (proj.type === 'MISSILE') {
         ctx.fillStyle = '#fff';
         if (qualitySettings.bloom) {
             ctx.shadowColor = '#f87171'; ctx.shadowBlur = 10;
         } else {
             ctx.shadowColor = '#f87171'; ctx.shadowBlur = 5;
         }
         ctx.beginPath(); ctx.arc(proj.pos.x, proj.pos.y, 3, 0, Math.PI*2); ctx.fill();
         ctx.shadowBlur = 0;
      } else if (proj.type === 'FLAK_SHELL') {
         ctx.fillStyle = '#fdba74';
         ctx.beginPath(); ctx.arc(proj.pos.x, proj.pos.y, 4, 0, Math.PI*2); ctx.fill();
      } else {
         ctx.save();
         ctx.translate(proj.pos.x, proj.pos.y);
         ctx.rotate(Math.atan2(proj.velocity.y, proj.velocity.x));
         ctx.fillStyle = '#fde047';
         if (qualitySettings.bloom) {
             ctx.shadowColor = '#fde047'; ctx.shadowBlur = 8;
         }
         ctx.fillRect(-4, -1, 8, 2);
         ctx.restore();
      }
    });

    // Particles
    particlesRef.current.forEach(p => {
        ctx.save();
        ctx.globalAlpha = p.life;
        ctx.fillStyle = p.color;
        if (p.type === 'SMOKE') {
             ctx.beginPath(); ctx.arc(p.pos.x, p.pos.y, p.size, 0, Math.PI*2); ctx.fill();
        } else {
             ctx.translate(p.pos.x, p.pos.y);
             if (qualitySettings.bloom && p.type === 'SPARK') {
                 ctx.shadowColor = p.color; ctx.shadowBlur = 5;
             }
             ctx.fillRect(-p.size/2, -p.size/2, p.size, p.size);
        }
        ctx.restore();
    });

    // Shockwaves
    shockwavesRef.current.forEach(sw => {
        ctx.save();
        ctx.beginPath();
        ctx.arc(sw.pos.x, sw.pos.y, sw.radius, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(255, 255, 255, ${sw.alpha})`;
        ctx.lineWidth = 4;
        ctx.stroke();
        ctx.restore();
    });

    // Floating Text
    ctx.font = "bold 12px JetBrains Mono";
    ctx.textAlign = "center";
    floatingTextsRef.current.forEach(ft => {
        ctx.save();
        ctx.globalAlpha = ft.life;
        ctx.fillStyle = ft.color;
        ctx.shadowColor = 'black';
        ctx.shadowBlur = 2;
        ctx.fillText(ft.text, ft.pos.x, ft.pos.y);
        ctx.restore();
    });

    // Explosions
    explosionsRef.current.forEach(exp => {
      ctx.fillStyle = exp.color;
      ctx.globalAlpha = exp.alpha;
      if (qualitySettings.bloom) {
          ctx.shadowColor = exp.color; ctx.shadowBlur = 25;
      }
      ctx.beginPath(); ctx.arc(exp.pos.x, exp.pos.y, exp.radius, 0, Math.PI * 2); ctx.fill();
      ctx.globalAlpha = 1;
      ctx.shadowBlur = 0;
    });

    // Scan Overlay
    if (activeSupport.scan) {
        const t = (Date.now() % 2000) / 2000;
        ctx.strokeStyle = `rgba(56, 189, 248, ${0.2 - t * 0.2})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, t * GAME_HEIGHT);
        ctx.lineTo(GAME_WIDTH, t * GAME_HEIGHT);
        ctx.stroke();
    }
    
    ctx.restore();
  };

  const render = useCallback(() => {
    updatePhysics();
    if (canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      if (ctx) draw(ctx);
    }
    requestRef.current = requestAnimationFrame(render);
  }, [isRunning, fogEnabled, qualitySettings, gameMode, activeSupport, upgrades]); 

  useEffect(() => {
    requestRef.current = requestAnimationFrame(render);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [render]);

  const getEventPos = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    
    let clientX, clientY;
    if ('touches' in e) {
      if (e.touches.length === 0) return null;
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = (e as React.MouseEvent).clientX;
      clientY = (e as React.MouseEvent).clientY;
    }

    const x = (clientX - rect.left) * (GAME_WIDTH / rect.width);
    const y = (clientY - rect.top) * (GAME_HEIGHT / rect.height);
    return { x, y };
  };

  const handleInteraction = (e: React.MouseEvent | React.TouchEvent) => {
    const pos = getEventPos(e);
    if (!pos) return;

    if (toolMode === ToolMode.SET_TARGET) {
      // Check for return command
      const clickedSpawn = spawnPointsRef.current.find(sp => distance(pos, sp) < 40);
      
      if (clickedSpawn) {
          // Return Command
          const updatedDrones = dronesRef.current.map(d => ({...d, returning: true, target: null}));
          setDrones(updatedDrones);
          spawnFloatingText(pos, "RETURN TO BASE", "#38bdf8");
          if (!isDraggingRef.current) onLog("Command: All units return to base.", "info");
      } else {
          // Normal Move Command
          setTarget(pos);
          const updatedDrones = dronesRef.current.map(d => d.returning ? {...d, returning: false, target: pos} : {...d, target: pos});
          setDrones(updatedDrones);
          if (!isDraggingRef.current) spawnFloatingText(pos, "MOVING", "#ffffff");
      }
    } else if (toolMode === ToolMode.PLACE_DEFENSE) {
      // Throttle placement to avoid stacking
      const tooClose = defensesRef.current.some(d => distance(d.pos, pos) < 20);
      if (tooClose) return;

      const newDef: Defense = {
        id: Math.random().toString(),
        pos,
        range: 0,
        cooldown: 0,
        lastFired: 0,
        type: activeDefenseType,
        angle: 0,
        revealed: true,
        health: 100, maxHealth: 100
      };
      if (activeDefenseType === 'SAM') { newDef.health = SAM_HEALTH; newDef.maxHealth = SAM_HEALTH; }
      else if (activeDefenseType === 'FLAK') { newDef.health = FLAK_HEALTH; newDef.maxHealth = FLAK_HEALTH; }
      else { newDef.health = AA_GUN_HEALTH; newDef.maxHealth = AA_GUN_HEALTH; }

      setDefenses(prev => [...prev, newDef]);
      spawnExplosion(pos, '#3b82f6', 20, false);
    } else if (toolMode === ToolMode.PLACE_SPAWN) {
      setSpawnPoints(prev => {
        if (prev.length < 3) return [...prev, pos];
        const distances = prev.map(p => distance(p, pos));
        let minIndex = 0;
        let minD = distances[0];
        for(let i=1; i<distances.length; i++){
            if(distances[i] < minD) {
                minD = distances[i];
                minIndex = i;
            }
        }
        const newPoints = [...prev];
        newPoints[minIndex] = pos;
        return newPoints;
      });
    } else if (toolMode === ToolMode.PLACE_INFRASTRUCTURE) {
        const tooClose = infrastructureRef.current.some(i => distance(i.pos, pos) < 30);
        if (tooClose) return;

        let hp = INFRA_POWER_HEALTH;
        if (activeInfraType === 'WAREHOUSE') hp = INFRA_FACTORY_HEALTH;
        if (activeInfraType === 'COMMAND_CENTER') hp = INFRA_COMMAND_HEALTH;
        if (activeInfraType === 'RADAR') hp = INFRA_RADAR_HEALTH;
        if (activeInfraType === 'JAMMER') hp = INFRA_JAMMER_HEALTH;
        if (activeInfraType === 'FUEL_DEPOT') hp = INFRA_FUEL_HEALTH;
        
        setInfrastructure(prev => [...prev, {
            id: Math.random().toString(),
            type: activeInfraType,
            pos,
            health: hp,
            maxHealth: hp,
            revealed: true,
            destroyed: false
        }]);
        spawnExplosion(pos, '#3b82f6', 20, false);
    } else if (toolMode === ToolMode.DELETE) {
        // Find closest object to delete
        // 1. Defenses
        const defIdx = defensesRef.current.findIndex(d => distance(d.pos, pos) < 30);
        if (defIdx !== -1) {
            setDefenses(prev => prev.filter((_, i) => i !== defIdx));
            spawnExplosion(pos, '#94a3b8', 30, false);
            return;
        }
        
        // 2. Infrastructure
        const infraIdx = infrastructureRef.current.findIndex(i => distance(i.pos, pos) < 30);
        if (infraIdx !== -1) {
            setInfrastructure(prev => prev.filter((_, i) => i !== infraIdx));
            spawnExplosion(pos, '#94a3b8', 30, false);
            return;
        }

        // 3. Spawn Points (Only if > 1)
        if (spawnPointsRef.current.length > 1) {
            const spawnIdx = spawnPointsRef.current.findIndex(sp => distance(sp, pos) < 30);
            if (spawnIdx !== -1) {
                 setSpawnPoints(prev => prev.filter((_, i) => i !== spawnIdx));
                 spawnExplosion(pos, '#94a3b8', 30, false);
            }
        }
    }
  };

  const handleMouseDown = (e: React.MouseEvent | React.TouchEvent) => {
      isDraggingRef.current = true;
      handleInteraction(e);
  };

  const handleMouseMove = (e: React.MouseEvent | React.TouchEvent) => {
      if (!isDraggingRef.current) return;
      // Only allow continuous painting for Target or Painting Walls/Defenses (if we wanted painting)
      // For now, continuous target moving is the main goal
      if (toolMode === ToolMode.SET_TARGET) {
         handleInteraction(e);
      }
  };

  const handleMouseUp = () => {
      isDraggingRef.current = false;
  };

  return (
    <div className="w-full h-full flex items-center justify-center bg-slate-900/50 overflow-hidden touch-none select-none relative">
        <canvas
        ref={canvasRef}
        width={GAME_WIDTH}
        height={GAME_HEIGHT}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchStart={handleMouseDown}
        onTouchMove={handleMouseMove}
        onTouchEnd={handleMouseUp}
        className="cursor-crosshair touch-none shadow-2xl"
        style={{ 
            width: 'auto', 
            height: 'auto', 
            maxWidth: '100%', 
            maxHeight: '100%',
            aspectRatio: `${GAME_WIDTH}/${GAME_HEIGHT}` 
        }}
        />
    </div>
  );
};

export default RadarMap;