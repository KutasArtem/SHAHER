
import { Medal, ShopItem } from './types';
import { PackagePlus, ShieldCheck, Gem, Trophy, Zap, Radio, Rocket, Shield, ScanEye, Flame } from 'lucide-react';

export const GAME_WIDTH = 1200;
export const GAME_HEIGHT = 800;

// DRONE STATS
export const DRONE_ATTACK_SPEED = 2.5;
export const DRONE_ATTACK_TURN = 0.05;
export const DRONE_ATTACK_SIZE = 6;
export const DRONE_ATTACK_VISION = 100; // Small vision
export const DRONE_DAMAGE = 110; // Base damage of a drone hit

export const DRONE_SCOUT_SPEED = 4.5; // Much faster
export const DRONE_SCOUT_TURN = 0.1; // More agile
export const DRONE_SCOUT_SIZE = 5;
export const DRONE_SCOUT_VISION = 300; // Large vision

export const DRONE_TURBO_SPEED = 6.0; // Jet engine
export const DRONE_TURBO_TURN = 0.03; // Hard to turn (low agility)
export const DRONE_TURBO_SIZE = 6;
export const DRONE_TURBO_COST = 50; // Credits

export const DRONE_STEALTH_SPEED = 3.0; // Balanced speed
export const DRONE_STEALTH_TURN = 0.07; // Decent agility
export const DRONE_STEALTH_SIZE = 5;
export const DRONE_STEALTH_COST = 100; // Expensive
export const DRONE_STEALTH_VISIBILITY = 0.4; // Enemies only see it at 40% range

export const SCOUT_RETURN_REWARD = 50; // Credits rewarded for safe return of a Scout

// AA GUN (ZU-23: Rapid fire, bullet stream)
export const AA_GUN_RANGE = 220;
export const AA_GUN_COOLDOWN = 8; 
export const AA_GUN_PROJECTILE_SPEED = 7;
export const AA_GUN_ACCURACY = 0.1; 
export const AA_GUN_HEALTH = 100;

// SAM (S-300: Long range, homing)
export const SAM_RANGE = 500;
export const SAM_COOLDOWN = 180; 
export const SAM_PROJECTILE_SPEED = 3.5; 
export const SAM_PROJECTILE_ACCEL = 0.15; 
export const SAM_HEALTH = 200; // Takes ~2 hits

// FLAK (S-60: Medium range, Area of Effect)
export const FLAK_RANGE = 350;
export const FLAK_COOLDOWN = 60; // 1 sec
export const FLAK_PROJECTILE_SPEED = 9; // Fast shell
export const FLAK_EXPLOSION_RADIUS = 45; // Big boom
export const FLAK_HEALTH = 150; 

// INFRASTRUCTURE
export const INFRA_POWER_HEALTH = 100;
export const INFRA_FACTORY_HEALTH = 200;
export const INFRA_RADAR_HEALTH = 80;
export const INFRA_COMMAND_HEALTH = 300;
export const INFRA_JAMMER_HEALTH = 150;
export const INFRA_FUEL_HEALTH = 80;

export const POWER_GRID_RADIUS = 300; // Defenses within this range of a Power Plant get power
export const JAMMER_RADIUS = 250; // Drones within this range get jammed
export const RADAR_REVEAL_RADIUS = 500; // Range of the Radar building

// ENEMY AI ECONOMY
export const ENEMY_INCOME_RATE = 10; // Credits per tick
export const ENEMY_REPAIR_COST = 150;
export const ENEMY_BUILD_COST_AA = 100;
export const ENEMY_BUILD_COST_SAM = 250;

export const INITIAL_SPAWN = { x: 100, y: GAME_HEIGHT / 2 };
export const INITIAL_TARGET = { x: GAME_WIDTH - 100, y: GAME_HEIGHT / 2 };

export const MEDAL_LIST: Medal[] = [
    { id: 'first_blood', name: 'First Blood', description: 'Destroy your first enemy defense to unlock the GHOST Drone.', icon: 'sword', unlocked: false },
    { id: 'tactician', name: 'Master Tactician', description: 'Win an Assault Operation.', icon: 'crosshair', unlocked: false },
    { id: 'demolition', name: 'Demolitionist', description: 'Destroy all infrastructure in Realistic Mode.', icon: 'hammer', unlocked: false },
    { id: 'ace', name: 'Ace Pilot', description: 'Reach Score 10 in Survival Mode.', icon: 'star', unlocked: false },
    { id: 'rich', name: 'War Profiteer', description: 'Accumulate 1000 Credits.', icon: 'coins', unlocked: false },
];

export const SHOP_ITEMS_LIST: ShopItem[] = [
    // FINANCE
    { id: 'starter', category: 'FINANCE', name: 'Starter Kit', description: '1,000 Credits', cost: 0.99, currency: 'USD', icon: PackagePlus, effectId: 'add_1000' },
    { id: 'mercenary', category: 'FINANCE', name: 'Mercenary Stash', description: '6,000 Credits (+20%)', cost: 4.99, currency: 'USD', icon: ShieldCheck, effectId: 'add_6000' },
    { id: 'warlord', category: 'FINANCE', name: 'Warlord Chest', description: '15,000 Credits (+50%)', cost: 9.99, currency: 'USD', icon: Gem, effectId: 'add_15000' },
    { id: 'dev_support', category: 'FINANCE', name: 'Dev Support', description: '50,000 Credits (+100%)', cost: 19.99, currency: 'USD', icon: Trophy, effectId: 'add_50000' },

    // SUPPORT
    { id: 'emp_blast', category: 'SUPPORT', name: 'EMP Blast', description: 'Disable ENEMY AA for 15s', cost: 1200, currency: 'CREDITS', icon: Zap, effectId: 'emp_15s' },
    { id: 'sat_link', category: 'SUPPORT', name: 'SAT-Link', description: 'Reveal Map for 30s', cost: 600, currency: 'CREDITS', icon: Radio, effectId: 'reveal_30s' },
    { id: 'supply_drop', category: 'SUPPORT', name: 'Reinforcements', description: '+5 Drones to Hangar', cost: 400, currency: 'CREDITS', icon: PackagePlus, effectId: 'add_5_drones' },
    { id: 'airstrike', category: 'SUPPORT', name: 'Tactical Strike', description: 'Destroy random enemy defense', cost: 2500, currency: 'CREDITS', icon: Flame, effectId: 'destroy_random' },

    // TECH
    { id: 'tech_speed', category: 'TECH', name: 'Afterburners', description: '+15% Flight Speed (Passive)', cost: 3000, currency: 'CREDITS', icon: Rocket, effectId: 'tech_speed', oneTime: true },
    { id: 'tech_armor', category: 'TECH', name: 'Titanium Hull', description: '25% Evasion Chance (Passive)', cost: 2500, currency: 'CREDITS', icon: Shield, effectId: 'tech_armor', oneTime: true },
    { id: 'tech_optics', category: 'TECH', name: 'Adv. Optics', description: '+30% Vision Range (Passive)', cost: 1500, currency: 'CREDITS', icon: ScanEye, effectId: 'tech_optics', oneTime: true },
];
